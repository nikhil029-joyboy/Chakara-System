
/* =========================================================
   NINJA SYSTEM — DUAL-HAND 3D CHAKRA SHIELD + BLAST EDITION — v3.7

   Automatic Jutsu Activation
   Independent Two-Hand Effects
   Chakra Shields
   Chakra Lightning Connection
   Ultimate Chakra Mode
   Ultimate Chakra Blast
   Charging + Release + Shockwaves + Particles

   Three.js + MediaPipe Hands
   ========================================================= */

// =========================================================
// HTML ELEMENTS
// =========================================================

const video = document.getElementById("video");
const handCanvas = document.getElementById("canvas");
const handCtx = handCanvas ? handCanvas.getContext("2d") : null;
const fxCanvas = document.getElementById("fxCanvas");

const startBtn = document.getElementById("startBtn");
const cameraStatus = document.getElementById("cameraStatus");
const handStatus = document.getElementById("handStatus");
const placeholder = document.getElementById("placeholder");
const activePower = document.getElementById("activePower");
const powerDescription = document.getElementById("powerDescription");
const detection = document.getElementById("detection");

// =========================================================
// SYSTEM VARIABLES
// =========================================================

let selectedPower = "fire";
let camera = null;
let threeReady = false;

let detectedHands = [];
let activeHands = [];
let fingerStatesByHand = [];
let handJutsu = [null, null];

let hands = null;
let trackingReady = false;
let handSmoothing = new Map();
let ultimateGestureHold = 0;
let ultimateGestureCooldown = 0;
let previousUltimateGesture = false;
let chakraAuraGroups = [];
let chakraCloakGroups = [];
let chakraCloakParticles = [];
let chakraCloakRings = [[], []];
let fusionGroup = null;
let fusionCore = null;
let fusionRings = [];
let fusionParticles = null;
let systemStatusPanel = null;
let statusUpdateClock = 0;

let renderer, scene, threeCamera;
let clock;
let resizeObserver;

let effectGroups = [];
let particleSystems = [];
let effectPowerByHand = [null, null];

let effectGroup = null;
let particleSystem = null;

// =========================================================
// CHAKRA SHIELD VARIABLES
// =========================================================

let chakraShieldGroups = [];

const SHIELD_COLORS = {
    fire: 0xffa45c,
    rasengan: 0x50cfff,
    lightning: 0xb69aff,
    rasenshuriken: 0x55e7ff,
    ultimate: 0xc4f5ff,
    default: 0x75cfff
};

// =========================================================
// CHAKRA LIGHTNING CONNECTION
// =========================================================

let chakraLinkGroup = null;
let chakraLinkCore = null;
let chakraLinkGlow = null;
let chakraLinkBranches = null;

let chakraLinkPulses = [];

let chakraLinkFade = 0;
let chakraLinkTargetFade = 0;

const CHAKRA_LINK_COLORS = {
    fire: 0xff713c,
    rasengan: 0x50cfff,
    lightning: 0x9b8cff,
    rasenshuriken: 0x55e7ff,
    ultimate: 0xb9f5ff,
    default: 0x50a9ff
};

// =========================================================
// ULTIMATE CHAKRA VARIABLES
// =========================================================

let ultimateGroup = null;
let ultimateActive = false;

let ultimateFade = 0;
let ultimateTargetFade = 0;

let ultimateParticles = null;
let ultimateCore = null;
let ultimateRings = [];

let ultimateCharge = 0;
const ULTIMATE_CHARGE_TIME = 4;
let ultimateMaxCharge = false;

// =========================================================
// ULTIMATE CHAKRA BLAST VARIABLES
// =========================================================

// =========================================================
// ULTIMATE CHAKRA BLAST VARIABLES
// =========================================================

let chakraBlastGroup = null;
let chakraBlastCore = null;
let chakraBlastGlow = null;
let chakraBlastFlash = null;

let chakraBlastRings = [];
let chakraBlastBeam = null;
let chakraBlastShockwaves = [];
let chakraBlastParticles = null;

let chakraBlastCharge = 0;
let chakraBlastCooldown = 0;

let chakraBlastActive = false;
let chakraBlastPhase = "idle";
let chakraBlastTimer = 0;

let previousBlastGesture = false;
let chakraBlastBurstStarted = false;

const CHAKRA_BLAST_CONFIG = {
    chargeTime: 3.6,
    cooldownTime: 3,
    blastDuration: 2.0,
    maxScale: 2.25,
    expansionSpeed: 5.6
};

// =========================================================
// POWER CONFIGURATION
// =========================================================

const powers = {
    fire: {
        name: "FIRE STYLE",
        description: "Great Fireball Jutsu",
        color: "#ff713c"
    },

    rasengan: {
        name: "RASENGAN",
        description: "Rotating Chakra Sphere",
        color: "#50a9ff"
    },

    lightning: {
        name: "CHIDORI",
        description: "Kakashi-inspired Lightning Style",
        color: "#c5a4ff"
    },

    rasenshuriken: {
        name: "RASENSHURIKEN",
        description: "Wind Style: Rasenshuriken",
        color: "#65e8ff"
    }
};

// =========================================================
// AUTOMATIC JUTSU SETTINGS
// =========================================================

const JUTSU_NAMES = {
    fire: "FIRE STYLE",
    rasengan: "RASENGAN",
    lightning: "CHIDORI",
    rasenshuriken: "RASENSHURIKEN"
};

let fistHistory = [[], []];
let previousHandPower = [null, null];

// COMBO SYSTEM: combos are registered when a hand newly activates a jutsu.
let comboSequence = [];
let comboCount = 0;
let comboEnergy = 0;
let comboWindow = 0;
let comboMessage = "WAITING FOR FIRST TECHNIQUE";
let comboDualSyncCooldown = 0;
const COMBO_WINDOW_SECONDS = 5;
const COMBO_POWER_NAMES = { fire: "FIRE", rasengan: "RASENGAN", lightning: "CHIDORI", rasenshuriken: "RASENSHURIKEN" };

// =========================================================
// JUTSU EVOLUTION + COMBO FINISHERS (v3.6)
// Evolution rises with sustained activation and technique mastery.
// =========================================================
let jutsuHoldSeconds = [0, 0];
let jutsuEvolutionStage = [0, 0]; // 0 NORMAL, 1 ENHANCED, 2 MAXIMUM
let comboFinisherTimer = 0;
let comboFinisherName = "";
let comboFinisherGroup = null;
let comboFinisherRings = [];
let comboFinisherParticles = null;
let dualSyncStateText = "WAITING FOR BOTH HANDS";
const EVOLUTION_ENHANCED_SECONDS = 1.6;
const EVOLUTION_MAXIMUM_SECONDS = 3.8;

function getJutsuEvolutionStage(handIndex) {
    const power = handJutsu[handIndex];
    if (!power) return 0;
    const mastery = jutsuMastery[power] || 0;
    const masteryBonus = mastery >= 30 ? 1.0 : mastery >= 15 ? 0.55 : mastery >= 5 ? 0.2 : 0;
    const charge = jutsuHoldSeconds[handIndex] + masteryBonus;
    return charge >= EVOLUTION_MAXIMUM_SECONDS ? 2 :
        charge >= EVOLUTION_ENHANCED_SECONDS ? 1 : 0;
}

function evolutionLabel(stage) {
    return stage >= 2 ? "MAXIMUM" : stage === 1 ? "ENHANCED" : "NORMAL";
}

function updateJutsuEvolutionSystem(delta) {
    for (let i = 0; i < 2; i++) {
        if (handJutsu[i]) jutsuHoldSeconds[i] = Math.min(8, jutsuHoldSeconds[i] + delta);
        else jutsuHoldSeconds[i] = Math.max(0, jutsuHoldSeconds[i] - delta * 2.8);
        jutsuEvolutionStage[i] = getJutsuEvolutionStage(i);
    }
    dualSyncStateText = detectedHands.length === 2
        ? (handJutsu[0] && handJutsu[1] && handJutsu[0] === handJutsu[1]
            ? "SYNCHRONIZED" : "TWO HANDS TRACKED")
        : "WAITING FOR BOTH HANDS";
}

function triggerComboFinisher(name) {
    comboFinisherName = name;
    comboFinisherTimer = 2.8;
    const banner = document.getElementById("comboFinisherBanner");
    if (banner) {
        banner.textContent = `✦ ${name} ✦`;
        banner.classList.remove("finisher-show");
        void banner.offsetWidth;
        banner.classList.add("finisher-show");
    }
    if (comboFinisherGroup) {
        comboFinisherGroup.visible = true;
        comboFinisherGroup.scale.setScalar(0.42);
        comboFinisherGroup.userData.life = 1;
    }
}

function buildComboFinisherEffect() {
    if (!scene || comboFinisherGroup) return;
    comboFinisherGroup = new THREE.Group();
    comboFinisherGroup.visible = false;
    const core = addSphere(comboFinisherGroup, 0.52, 0x4acaff, 0.55, [1, 1, 0.55]);
    core.userData.role = "finisherCore";
    comboFinisherRings = [];
    for (let i = 0; i < 5; i++) {
        const ring = addTorus(comboFinisherGroup, 0.72 + i * 0.13, 0.018,
            i % 2 ? 0x8beeff : 0x168cff, 0.76);
        ring.rotation.set(i * 0.6, i * 0.37, i * 0.8);
        ring.userData.spin = i % 2 ? 2.8 : -2.2;
        comboFinisherRings.push(ring);
    }
    comboFinisherParticles = createParticleField(comboFinisherGroup, 180, 0x65dfff, 2.5, 0.035);
    scene.add(comboFinisherGroup);
    captureEffectMaterials(comboFinisherGroup);
}

function animateComboFinisher(delta, time) {
    if (comboFinisherTimer > 0) comboFinisherTimer = Math.max(0, comboFinisherTimer - delta);
    if (!comboFinisherGroup || !comboFinisherGroup.visible) return;
    const life = Math.max(0, comboFinisherTimer / 2.8);
    comboFinisherGroup.userData.life = life;
    comboFinisherGroup.position.set(0, 0, 0.5);
    comboFinisherGroup.scale.setScalar((0.42 + (1 - life) * 0.55) * (1 + Math.sin(time * 13) * 0.035));
    comboFinisherRings.forEach(r => {
        r.rotation.x += delta * r.userData.spin;
        r.rotation.y -= delta * r.userData.spin * 0.7;
        r.material.userData.effectOpacity = 0.72 * life;
    });
    comboFinisherGroup.children.forEach(child => {
        if (child.userData.role === "finisherCore") {
            child.material.userData.effectOpacity = 0.65 * life;
            child.scale.setScalar(0.8 + Math.sin(time * 16) * 0.12);
        }
    });
    updateParticles(comboFinisherParticles, delta, time);
    applyEffectFade(comboFinisherGroup, life);
    if (comboFinisherTimer <= 0) comboFinisherGroup.visible = false;
}


// =========================================================
// SHINOBI RANK & EXPERIENCE PROGRESSION (v3.0)
// Progress is saved locally in this browser.
// =========================================================

const SHINOBI_RANKS = [
    { name: "ACADEMY STUDENT", xp: 0 },
    { name: "GENIN", xp: 100 },
    { name: "CHUNIN", xp: 300 },
    { name: "JONIN", xp: 650 },
    { name: "ANBU", xp: 1100 },
    { name: "KAGE", xp: 1800 }
];

const SHINOBI_XP_KEY = "ninjaSystem_v3_shinobiXP";
let shinobiXP = 0;
let lastXPReward = 0;
let rankMessageText = "Activate techniques and complete combos to earn experience.";

try {
    const savedXP = Number(localStorage.getItem(SHINOBI_XP_KEY));
    if (Number.isFinite(savedXP) && savedXP >= 0) shinobiXP = Math.floor(savedXP);
} catch (error) {
    console.warn("Shinobi XP could not be loaded from local storage:", error);
}

function getShinobiRank(xp = shinobiXP) {
    let current = SHINOBI_RANKS[0];
    let next = null;
    for (let i = 0; i < SHINOBI_RANKS.length; i++) {
        if (xp >= SHINOBI_RANKS[i].xp) current = SHINOBI_RANKS[i];
        else { next = SHINOBI_RANKS[i]; break; }
    }
    return { current, next };
}

function updateShinobiProgressUI() {
    const rank = getShinobiRank();
    const previous = SHINOBI_RANKS.find(item => item.name === rank.current.name) || SHINOBI_RANKS[0];
    const next = rank.next;
    const currentRankEl = document.getElementById("currentRank");
    const badgeEl = document.getElementById("rankBadge");
    const totalEl = document.getElementById("totalXP");
    const nextEl = document.getElementById("nextRank");
    const rewardEl = document.getElementById("lastXPReward");
    const fillEl = document.getElementById("rankProgressFill");
    const progressTextEl = document.getElementById("rankProgressText");
    const remainingEl = document.getElementById("rankRemaining");
    const messageEl = document.getElementById("rankMessage");

    if (currentRankEl) currentRankEl.textContent = rank.current.name;
    if (badgeEl) badgeEl.textContent = rank.current.name;
    if (totalEl) totalEl.textContent = `${shinobiXP.toLocaleString()} XP`;
    if (nextEl) nextEl.textContent = next ? next.name : "MAX RANK";
    if (rewardEl) rewardEl.textContent = `+${lastXPReward} XP`;

    if (next) {
        const span = next.xp - previous.xp;
        const earned = Math.max(0, shinobiXP - previous.xp);
        const percent = Math.max(0, Math.min(100, (earned / span) * 100));
        if (fillEl) fillEl.style.width = `${percent}%`;
        if (progressTextEl) progressTextEl.textContent = `${earned} / ${span} XP`;
        if (remainingEl) remainingEl.textContent = `${Math.max(0, next.xp - shinobiXP)} XP TO ${next.name}`;
    } else {
        if (fillEl) fillEl.style.width = "100%";
        if (progressTextEl) progressTextEl.textContent = "MAXIMUM RANK ACHIEVED";
        if (remainingEl) remainingEl.textContent = "ALL RANKS UNLOCKED";
    }
    if (messageEl) messageEl.textContent = rankMessageText;
}

function awardShinobiXP(amount, reason) {
    const points = Math.max(0, Math.floor(Number(amount) || 0));
    if (!points) return;
    const oldRank = getShinobiRank().current.name;
    shinobiXP += points;
    lastXPReward = points;
    const newRank = getShinobiRank().current.name;
    rankMessageText = newRank !== oldRank
        ? `RANK UP! ${newRank} UNLOCKED — ${reason} (+${points} XP)`
        : `${reason} (+${points} XP)`;
    if (newRank !== oldRank && typeof v37Notify === "function") {
        v37Notify(`SHINOBI RANK UP // ${newRank}`, "rank");
        document.body.classList.add("v37-rank-flash");
        window.setTimeout(() => document.body.classList.remove("v37-rank-flash"), 850);
    }
    try {
        localStorage.setItem(SHINOBI_XP_KEY, String(shinobiXP));
    } catch (error) {
        console.warn("Shinobi XP could not be saved:", error);
    }
    updateShinobiProgressUI();
}

updateShinobiProgressUI();

// =========================================================
// JUTSU MASTERY SYSTEM (v3.1)
// Each activated hand adds one mastery point to its selected technique.
// Progress is stored locally and does not alter the existing jutsu controls.
// =========================================================
const JUTSU_MASTERY_KEY = "ninjaSystem_v3_jutsuMastery";
const MASTERY_CAP = 50;
const MASTERY_TIERS = [
    { name: "NOVICE", points: 0 },
    { name: "APPRENTICE", points: 5 },
    { name: "SKILLED", points: 15 },
    { name: "EXPERT", points: 30 },
    { name: "MASTER", points: 50 }
];
let jutsuMastery = { fire: 0, rasengan: 0, lightning: 0, rasenshuriken: 0 };
let masteryMessageText = "Activate a jutsu to earn mastery for that technique.";

try {
    const savedMastery = JSON.parse(localStorage.getItem(JUTSU_MASTERY_KEY) || "null");
    if (savedMastery && typeof savedMastery === "object") {
        for (const key of Object.keys(jutsuMastery)) {
            const value = Number(savedMastery[key]);
            if (Number.isFinite(value) && value >= 0) jutsuMastery[key] = Math.min(MASTERY_CAP, Math.floor(value));
        }
    }
} catch (error) {
    console.warn("Jutsu mastery could not be loaded:", error);
}

function getMasteryTier(points) {
    let current = MASTERY_TIERS[0];
    let next = null;
    for (const tier of MASTERY_TIERS) {
        if (points >= tier.points) current = tier;
        else { next = tier; break; }
    }
    return { current, next };
}

function updateJutsuMasteryUI() {
    let total = 0;
    for (const key of Object.keys(jutsuMastery)) {
        const points = jutsuMastery[key];
        total += points;
        const tier = getMasteryTier(points);
        const tierEl = document.getElementById(`${key}MasteryTier`);
        const valueEl = document.getElementById(`${key}MasteryValue`);
        const fillEl = document.getElementById(`${key}MasteryFill`);
        const nextEl = document.getElementById(`${key}MasteryNext`);
        if (tierEl) tierEl.textContent = tier.current.name;
        if (valueEl) valueEl.textContent = `${points} / ${MASTERY_CAP}`;
        if (fillEl) fillEl.style.width = `${(points / MASTERY_CAP) * 100}%`;
        if (nextEl) nextEl.textContent = tier.next
            ? `${tier.next.points - points} mastery points to ${tier.next.name}`
            : "MAXIMUM MASTERY REACHED";
    }
    const totalEl = document.getElementById("masteryTotal");
    const messageEl = document.getElementById("masteryMessage");
    if (totalEl) totalEl.textContent = `${total} / 200`;
    if (messageEl) messageEl.textContent = masteryMessageText;
}

function awardJutsuMastery(power, amount = 1) {
    if (!Object.prototype.hasOwnProperty.call(jutsuMastery, power)) return;
    const previous = jutsuMastery[power];
    jutsuMastery[power] = Math.min(MASTERY_CAP, previous + Math.max(1, Math.floor(amount)));
    if (jutsuMastery[power] > previous) {
        const tier = getMasteryTier(jutsuMastery[power]).current.name;
        const previousTier = getMasteryTier(previous).current.name;
        masteryMessageText = tier !== previousTier
            ? `${COMBO_POWER_NAMES[power]} MASTERY RANK UP — ${tier}`
            : `${COMBO_POWER_NAMES[power]} MASTERY +${jutsuMastery[power] - previous} POINT${jutsuMastery[power] - previous === 1 ? "" : "S"}`;
        try { localStorage.setItem(JUTSU_MASTERY_KEY, JSON.stringify(jutsuMastery)); }
        catch (error) { console.warn("Jutsu mastery could not be saved:", error); }
        updateJutsuMasteryUI();
    }
}

updateJutsuMasteryUI();

// =========================================================
// CHAKRA COMBO SYSTEM
// =========================================================

function updateComboUI() {
    const countEl = document.getElementById("comboCount");
    const messageEl = document.getElementById("comboMessage");
    const timerEl = document.getElementById("comboTimer");
    const chainEl = document.getElementById("comboChain");
    const energyEl = document.getElementById("comboEnergyText");
    const fillEl = document.getElementById("comboMeterFill");

    if (countEl) countEl.textContent = String(comboCount);
    if (messageEl) messageEl.textContent = comboMessage;
    if (timerEl) timerEl.textContent = comboWindow > 0 ? `${comboWindow.toFixed(1)}s` : "READY";
    if (chainEl) chainEl.textContent = comboSequence.length
        ? comboSequence.map(power => COMBO_POWER_NAMES[power] || power.toUpperCase()).join(" → ")
        : "—";
    if (energyEl) energyEl.textContent = `${Math.round(comboEnergy)}%`;
    if (fillEl) fillEl.style.width = `${comboEnergy}%`;
}

function resetComboSystem(showMessage = true) {
    comboSequence = [];
    comboWindow = 0;
    comboEnergy = 0;
    if (showMessage) comboMessage = "COMBO RESET — READY";
    updateComboUI();
}

function registerComboActivation(power, dualSync = false) {
    if (!powers[power]) return;

    if (dualSync) {
        awardJutsuMastery(power, 2);
        awardShinobiXP(20, "DUAL SYNC ACTIVATED");
        comboCount += 1;
        comboEnergy = Math.min(100, comboEnergy + 30);
        comboSequence = [power, power];
        comboWindow = COMBO_WINDOW_SECONDS;
        comboMessage = `DUAL SYNC! ${COMBO_POWER_NAMES[power]} × 2`;
        updateComboUI();
        return;
    }

    awardJutsuMastery(power, 1);
    awardShinobiXP(10, `${COMBO_POWER_NAMES[power]} ACTIVATED`);
    if (comboWindow <= 0) comboSequence = [];
    const previous = comboSequence[comboSequence.length - 1];
    if (previous !== power) comboSequence.push(power);
    comboSequence = comboSequence.slice(-3);
    comboWindow = COMBO_WINDOW_SECONDS;

    const chain = comboSequence.join(">");
    let completedName = "";
    if (chain === "rasengan>lightning") completedName = "LIGHTNING SPIRAL COMBO";
    if (chain === "fire>rasengan>lightning") completedName = "TRIPLE CHAKRA COMBO";
    if (chain === "rasengan>rasenshuriken") completedName = "WIND SPIRAL COMBO";

    if (completedName) {
        awardShinobiXP(chain === "fire>rasengan>lightning" ? 45 : 30, completedName);
        comboCount += 1;
        comboEnergy = Math.min(100, comboEnergy + (chain === "fire>rasengan>lightning" ? 45 : 35));
        comboMessage = `${completedName} COMPLETE!`;
        triggerComboFinisher(completedName);
        // Keep the final technique as the start of a possible next chain.
        comboSequence = [power];
    } else {
        comboMessage = `${COMBO_POWER_NAMES[power]} ACTIVATED — CHAIN THE NEXT JUTSU`;
        comboEnergy = Math.min(100, comboEnergy + 8);
    }
    updateComboUI();
}

function updateComboSystem(delta) {
    if (comboWindow > 0) {
        comboWindow = Math.max(0, comboWindow - delta);
        if (comboWindow === 0) {
            comboSequence = [];
            if (comboMessage.includes("CHAIN") || comboMessage.includes("ACTIVATED")) {
                comboMessage = "COMBO WINDOW EXPIRED — READY";
            }
        }
    }
    if (comboDualSyncCooldown > 0) comboDualSyncCooldown = Math.max(0, comboDualSyncCooldown - delta);
    comboEnergy = Math.max(0, comboEnergy - delta * 1.6);
    updateComboUI();
}

// =========================================================
// TECHNIQUE SELECTION + STATUS INTERFACE

function selectPower(power) {
    if (!powers[power]) return;
    selectedPower = power;

    document.querySelectorAll(".power-card").forEach(card => {
        card.classList.toggle("active", card.dataset.power === power);
    });

    if (activePower) {
        activePower.textContent = powers[power].name;
        activePower.style.color = powers[power].color;
    }
    if (powerDescription) powerDescription.textContent = powers[power].description;

    rebuildAllEffects();
    updateSystemStatus(true);
    if (typeof v37Notify === "function") v37Notify(`${powers[power].name} SELECTED`, power);
}

document.querySelectorAll(".power-card").forEach(card => {
    card.addEventListener("click", () => selectPower(card.dataset.power));
});

const resetComboBtn = document.getElementById("resetComboBtn");
if (resetComboBtn) resetComboBtn.addEventListener("click", () => resetComboSystem(true));
updateComboUI();

function buildSystemStatusInterface() {
    if (systemStatusPanel) return;
    const host = fxCanvas?.parentElement || document.body;
    if (!host) return;

    if (getComputedStyle(host).position === "static") host.style.position = "relative";

    const style = document.createElement("style");
    style.textContent = `
      .ninja-system-panel{position:absolute;z-index:20;right:14px;top:14px;left:auto;
      width:min(250px,calc(100% - 24px));padding:12px 14px;color:#e8f8ff;
      background:rgba(3,12,27,.80);border:1px solid rgba(93,205,255,.38);
      border-radius:12px;box-shadow:0 8px 28px rgba(0,0,0,.28);
      backdrop-filter:blur(10px);font:12px/1.5 system-ui,sans-serif;pointer-events:none}
      .ninja-system-panel strong{color:#8eeaff;letter-spacing:.12em}
      .ninja-system-row{display:flex;justify-content:space-between;gap:10px}
      .ninja-system-value{color:#a9e8ff;text-align:right}
      .ninja-system-meter{height:5px;background:rgba(255,255,255,.12);
      border-radius:8px;overflow:hidden;margin:5px 0 8px}
      .ninja-system-meter span{display:block;height:100%;width:0%;
      background:linear-gradient(90deg,#168cff,#b9f5ff);transition:width .12s}
    `;
    document.head.appendChild(style);

    systemStatusPanel = document.createElement("div");
    systemStatusPanel.className = "ninja-system-panel";
    systemStatusPanel.innerHTML = `
      <strong>NINJA SYSTEM</strong>
      <div class="ninja-system-row"><span>CAMERA</span><span id="nsCamera" class="ninja-system-value">OFFLINE</span></div>
      <div class="ninja-system-row"><span>TRACKING</span><span id="nsTracking" class="ninja-system-value">WAITING</span></div>
      <div class="ninja-system-row"><span>HANDS</span><span id="nsHands" class="ninja-system-value">0 / 2</span></div>
      <div class="ninja-system-row"><span>HAND 1</span><span id="nsLeft" class="ninja-system-value">IDLE</span></div>
      <div class="ninja-system-row"><span>HAND 2</span><span id="nsRight" class="ninja-system-value">IDLE</span></div>
      <div class="ninja-system-row"><span>ULTIMATE MODE</span><span id="nsUltimate" class="ninja-system-value">OFF</span></div>
      <div class="ninja-system-row"><span>BLAST</span><span id="nsBlast" class="ninja-system-value">READY</span></div>
      <div class="ninja-system-meter"><span id="nsCharge"></span></div>
      <div class="ninja-system-row"><span>CHAKRA CHARGE</span><span id="nsChargeText" class="ninja-system-value">0%</span></div>
      <div class="ninja-system-row"><span>SELECTED JUTSU</span><span id="nsPower" class="ninja-system-value">FIRE STYLE</span></div>
      <div class="ninja-system-row"><span>HAND 1 EVOLUTION</span><span id="nsEvolution1" class="ninja-system-value">NORMAL</span></div>
      <div class="ninja-system-row"><span>HAND 2 EVOLUTION</span><span id="nsEvolution2" class="ninja-system-value">NORMAL</span></div>
      <div class="ninja-system-row"><span>DUAL SYNC</span><span id="nsDualSync" class="ninja-system-value">WAITING</span></div>
      <div class="ninja-system-row"><span>LAST FINISHER</span><span id="nsFinisher" class="ninja-system-value">—</span></div>
    `;
    host.appendChild(systemStatusPanel);
    if (typeof v37InstallCameraHUD === "function") v37InstallCameraHUD(host);
    if (typeof v37InstallThemeControl === "function") v37InstallThemeControl(systemStatusPanel);
}

function setStatusText(id, value) {
    const el = document.getElementById(id);
    if (el) el.textContent = value;
}

function updateSystemStatus() {
    if (!systemStatusPanel) return;
    setStatusText("nsCamera", camera ? "CONNECTED" : "OFFLINE");
    setStatusText("nsTracking", trackingReady ? "ACTIVE" : "WAITING");
    setStatusText("nsHands", `${detectedHands.length} / 2`);
    setStatusText("nsLeft", handJutsu[0] ? JUTSU_NAMES[handJutsu[0]] : "IDLE");
    setStatusText("nsRight", handJutsu[1] ? JUTSU_NAMES[handJutsu[1]] : "IDLE");
    setStatusText("nsUltimate", ultimateActive ? "ACTIVE" : "OFF");
    setStatusText("nsBlast",
        chakraBlastPhase === "charging" ? "CHARGING" :
        chakraBlastPhase === "blasting" ? "RELEASED" :
        chakraBlastCooldown > 0 ? `COOLDOWN ${chakraBlastCooldown.toFixed(1)}s` : "READY"
    );
    const charge = Math.round(Math.max(ultimateCharge, chakraBlastCharge) * 100);
    const meter = document.getElementById("nsCharge");
    if (meter) meter.style.width = `${charge}%`;
    setStatusText("nsChargeText", `${charge}%`);
    setStatusText("nsPower", powers[selectedPower]?.name || "IDLE");
    setStatusText("nsEvolution1", evolutionLabel(jutsuEvolutionStage[0]));
    setStatusText("nsEvolution2", evolutionLabel(jutsuEvolutionStage[1]));
    setStatusText("nsDualSync", dualSyncStateText);
    setStatusText("nsFinisher", comboFinisherName || "—");
    if (typeof v37UpdateHUD === "function") v37UpdateHUD();
}


// =========================================================
// NINJA SYSTEM v3.7 — LIVING HOLOGRAPHIC HUD
// Animated ambient background, radar, hand lock-on, themes,
// notifications, boot sequence and synchronized energy meters.
// =========================================================
const V37_THEMES = [
    { id: "chakra", name: "BLUE CHAKRA", accent: "#54dfff", rgb: "84,223,255" },
    { id: "lightning", name: "PURPLE LIGHTNING", accent: "#b79aff", rgb: "183,154,255" },
    { id: "fire", name: "FIRE ORANGE", accent: "#ff9a52", rgb: "255,154,82" },
    { id: "ultimate", name: "ULTIMATE WHITE", accent: "#eafaff", rgb: "234,250,255" }
];
let v37ThemeIndex = 0;
let v37AmbientCanvas = null;
let v37AmbientCtx = null;
let v37AmbientParticles = [];
let v37RadarCanvas = null;
let v37RadarCtx = null;
let v37HudRoot = null;
let v37Toast = null;
let v37ToastTimer = 0;
let v37HandLocks = [];
let v37LastNotification = "";
let v37BootOverlay = null;
let v37AmbientFrame = 0;
let v37AmbientLast = 0;

function v37Theme() { return V37_THEMES[v37ThemeIndex]; }

function v37ApplyTheme(index) {
    v37ThemeIndex = (index + V37_THEMES.length) % V37_THEMES.length;
    const theme = v37Theme();
    document.body.dataset.v37Theme = theme.id;
    document.documentElement.style.setProperty("--v37-accent", theme.accent);
    document.documentElement.style.setProperty("--v37-accent-rgb", theme.rgb);
    const label = document.getElementById("v37ThemeName");
    if (label) label.textContent = theme.name;
    if (v37Toast) v37Notify(`HUD THEME // ${theme.name}`, "theme");
}

function v37Notify(message, type = "system") {
    if (!v37Toast) return;
    v37Toast.textContent = message;
    v37Toast.dataset.type = type;
    v37Toast.classList.remove("v37-toast-show");
    void v37Toast.offsetWidth;
    v37Toast.classList.add("v37-toast-show");
    v37LastNotification = message;
    if (v37ToastTimer) window.clearTimeout(v37ToastTimer);
    v37ToastTimer = window.setTimeout(() => v37Toast?.classList.remove("v37-toast-show"), 2600);
}

function v37InstallThemeControl(panel) {
    if (!panel || panel.querySelector(".v37-theme-control")) return;
    const control = document.createElement("button");
    control.type = "button";
    control.className = "v37-theme-control";
    control.innerHTML = `HUD THEME <span id="v37ThemeName">BLUE CHAKRA</span> <b>↻</b>`;
    control.addEventListener("click", () => v37ApplyTheme(v37ThemeIndex + 1));
    panel.appendChild(control);
}

function v37InstallCameraHUD(host) {
    const screen = fxCanvas?.parentElement;
    if (!screen || screen.querySelector(".v37-hud-root")) return;
    screen.classList.add("v37-camera-screen");

    v37HudRoot = document.createElement("div");
    v37HudRoot.className = "v37-hud-root";
    v37HudRoot.innerHTML = `
      <div class="v37-hud-corner v37-corner-tl"></div>
      <div class="v37-hud-corner v37-corner-tr"></div>
      <div class="v37-hud-corner v37-corner-bl"></div>
      <div class="v37-hud-corner v37-corner-br"></div>
      <div class="v37-radar-shell">
        <div class="v37-radar-title">CHAKRA RADAR <span>LIVE</span></div>
        <canvas class="v37-radar-canvas" width="180" height="180"></canvas>
        <div class="v37-radar-footer"><span>HAND 1</span><span>HAND 2</span></div>
      </div>
      <div class="v37-toast" role="status" aria-live="polite"></div>
      <div class="v37-lock-layer"></div>
      <div class="v37-camera-readout"><span>TRACKING ARRAY</span><b>V3.7</b></div>
    `;
    screen.appendChild(v37HudRoot);
    v37RadarCanvas = v37HudRoot.querySelector(".v37-radar-canvas");
    v37RadarCtx = v37RadarCanvas?.getContext("2d");
    v37Toast = v37HudRoot.querySelector(".v37-toast");
    const lockLayer = v37HudRoot.querySelector(".v37-lock-layer");
    for (let i = 0; i < 2; i++) {
        const lock = document.createElement("div");
        lock.className = `v37-hand-lock v37-hand-lock-${i + 1}`;
        lock.innerHTML = `<i></i><i></i><i></i><i></i><span>HAND ${i + 1} // LOCK</span>`;
        lockLayer.appendChild(lock);
        v37HandLocks.push(lock);
    }
    v37Notify("HUD ONLINE // AWAITING HANDS", "system");
}

function v37InstallBackground() {
    if (v37AmbientCanvas) return;
    v37AmbientCanvas = document.createElement("canvas");
    v37AmbientCanvas.id = "v37AmbientCanvas";
    v37AmbientCanvas.setAttribute("aria-hidden", "true");
    document.body.prepend(v37AmbientCanvas);
    v37AmbientCtx = v37AmbientCanvas.getContext("2d", { alpha: true });
    v37ResizeBackground();
    const count = Math.min(78, Math.max(38, Math.floor((window.innerWidth * window.innerHeight) / 22000)));
    v37AmbientParticles = Array.from({ length: count }, () => ({
        x: Math.random() * window.innerWidth,
        y: Math.random() * window.innerHeight,
        r: 0.7 + Math.random() * 2.0,
        vx: (Math.random() - 0.5) * 0.22,
        vy: -0.08 - Math.random() * 0.34,
        phase: Math.random() * Math.PI * 2,
        alpha: 0.12 + Math.random() * 0.35
    }));
    window.addEventListener("resize", v37ResizeBackground, { passive: true });
    v37AmbientFrame = requestAnimationFrame(v37AnimateBackground);
}

function v37ResizeBackground() {
    if (!v37AmbientCanvas) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
    v37AmbientCanvas.width = Math.floor(window.innerWidth * dpr);
    v37AmbientCanvas.height = Math.floor(window.innerHeight * dpr);
    v37AmbientCanvas.style.width = `${window.innerWidth}px`;
    v37AmbientCanvas.style.height = `${window.innerHeight}px`;
    v37AmbientCtx?.setTransform(dpr, 0, 0, dpr, 0, 0);
}

function v37AnimateBackground(timestamp) {
    if (!v37AmbientCtx || !v37AmbientCanvas) return;
    const ctx = v37AmbientCtx;
    const width = window.innerWidth, height = window.innerHeight;
    const dt = Math.min(2.2, (timestamp - (v37AmbientLast || timestamp)) / 16.67);
    v37AmbientLast = timestamp;
    const theme = v37Theme();
    ctx.clearRect(0, 0, width, height);

    // Ambient energy haze and a slow holographic grid.
    const glow = ctx.createRadialGradient(width * 0.5, height * 0.42, 0, width * 0.5, height * 0.42, Math.max(width, height) * 0.72);
    glow.addColorStop(0, `rgba(${theme.rgb},0.075)`);
    glow.addColorStop(0.55, `rgba(${theme.rgb},0.025)`);
    glow.addColorStop(1, "rgba(0,0,0,0)");
    ctx.fillStyle = glow;
    ctx.fillRect(0, 0, width, height);

    ctx.save();
    ctx.strokeStyle = `rgba(${theme.rgb},0.055)`;
    ctx.lineWidth = 1;
    const gridSize = 58;
    const drift = (timestamp * 0.006) % gridSize;
    for (let x = -gridSize + drift; x < width + gridSize; x += gridSize) {
        ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x - height * 0.12, height); ctx.stroke();
    }
    for (let y = (timestamp * 0.009) % gridSize; y < height; y += gridSize) {
        ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(width, y); ctx.stroke();
    }
    ctx.restore();

    // Floating chakra fragments with nearby particle links.
    const points = v37AmbientParticles;
    for (let i = 0; i < points.length; i++) {
        const p = points[i];
        p.x += p.vx * dt; p.y += p.vy * dt;
        p.phase += 0.025 * dt;
        if (p.y < -8) { p.y = height + 8; p.x = Math.random() * width; }
        if (p.x < -8) p.x = width + 8;
        if (p.x > width + 8) p.x = -8;
        const a = p.alpha * (0.68 + Math.sin(p.phase) * 0.32);
        ctx.beginPath();
        ctx.fillStyle = `rgba(${theme.rgb},${a})`;
        ctx.shadowColor = theme.accent;
        ctx.shadowBlur = 10;
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fill();
        ctx.shadowBlur = 0;
        for (let j = i + 1; j < points.length; j++) {
            const q = points[j], dx = p.x - q.x, dy = p.y - q.y;
            const dist = Math.hypot(dx, dy);
            if (dist < 110) {
                ctx.strokeStyle = `rgba(${theme.rgb},${0.045 * (1 - dist / 110)})`;
                ctx.beginPath(); ctx.moveTo(p.x, p.y); ctx.lineTo(q.x, q.y); ctx.stroke();
            }
        }
    }

    // Slow flowing energy ribbons.
    for (let band = 0; band < 3; band++) {
        ctx.beginPath();
        const baseY = height * (0.32 + band * 0.23);
        for (let x = 0; x <= width; x += 18) {
            const y = baseY + Math.sin(x * 0.006 + timestamp * 0.00028 + band) * 26
                + Math.sin(x * 0.012 - timestamp * 0.00018) * 10;
            if (x === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
        }
        ctx.strokeStyle = `rgba(${theme.rgb},${0.025 + band * 0.006})`;
        ctx.lineWidth = 1.4;
        ctx.stroke();
    }

    v37DrawRadar(timestamp);
    v37AmbientFrame = requestAnimationFrame(v37AnimateBackground);
}

function v37DrawRadar(timestamp) {
    const ctx = v37RadarCtx;
    if (!ctx) return;
    const w = 180, h = 180, cx = 90, cy = 90, radius = 78;
    const theme = v37Theme();
    ctx.clearRect(0, 0, w, h);
    ctx.save();
    ctx.strokeStyle = `rgba(${theme.rgb},0.22)`;
    ctx.lineWidth = 1;
    for (let r = 20; r <= radius; r += 20) {
        ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.stroke();
    }
    ctx.beginPath(); ctx.moveTo(cx - radius, cy); ctx.lineTo(cx + radius, cy); ctx.moveTo(cx, cy - radius); ctx.lineTo(cx, cy + radius); ctx.stroke();
    const angle = timestamp * 0.0012;
    const sweep = ctx.createRadialGradient(cx, cy, 0, cx, cy, radius);
    sweep.addColorStop(0, `rgba(${theme.rgb},0.01)`);
    sweep.addColorStop(1, `rgba(${theme.rgb},0.18)`);
    ctx.save(); ctx.translate(cx, cy); ctx.rotate(angle);
    ctx.beginPath(); ctx.moveTo(0, 0); ctx.arc(0, 0, radius, -0.28, 0.28); ctx.closePath();
    ctx.fillStyle = sweep; ctx.fill(); ctx.restore();
    detectedHands.slice(0, 2).forEach((hand, index) => {
        const p = hand?.[9];
        if (!p) return;
        const x = cx + (p.x - 0.5) * radius * 1.65;
        const y = cy + (p.y - 0.5) * radius * 1.65;
        const pulse = 4 + Math.sin(timestamp * 0.008 + index) * 1.5;
        ctx.beginPath(); ctx.arc(x, y, pulse, 0, Math.PI * 2);
        ctx.fillStyle = theme.accent; ctx.shadowColor = theme.accent; ctx.shadowBlur = 12; ctx.fill(); ctx.shadowBlur = 0;
        ctx.fillStyle = `rgba(${theme.rgb},0.8)`; ctx.font = "8px monospace"; ctx.fillText(`H${index + 1}`, x + 8, y - 7);
    });
    ctx.restore();
}

function v37UpdateHandLocks() {
    const screen = fxCanvas?.parentElement;
    if (!screen || !v37HandLocks.length) return;
    const rect = screen.getBoundingClientRect();
    for (let i = 0; i < 2; i++) {
        const lock = v37HandLocks[i];
        const hand = detectedHands[i];
        if (!hand || !hand.length) { lock.classList.remove("v37-lock-active"); continue; }
        let minX = 1, minY = 1, maxX = 0, maxY = 0;
        hand.forEach(p => { minX = Math.min(minX,p.x); minY = Math.min(minY,p.y); maxX = Math.max(maxX,p.x); maxY = Math.max(maxY,p.y); });
        const left = (1 - maxX) * rect.width - 24;
        const top = minY * rect.height - 24;
        const width = Math.max(58, (maxX - minX) * rect.width + 48);
        const height = Math.max(58, (maxY - minY) * rect.height + 48);
        lock.style.left = `${Math.max(8, Math.min(rect.width - width - 8, left))}px`;
        lock.style.top = `${Math.max(8, Math.min(rect.height - height - 8, top))}px`;
        lock.style.width = `${Math.min(rect.width - 16, width)}px`;
        lock.style.height = `${Math.min(rect.height - 16, height)}px`;
        lock.classList.toggle("v37-lock-active", true);
        lock.classList.toggle("v37-lock-jutsu", Boolean(handJutsu[i]));
        const label = lock.querySelector("span");
        if (label) label.textContent = handJutsu[i] ? `H${i + 1} // ${JUTSU_NAMES[handJutsu[i]]}` : `HAND ${i + 1} // LOCK`;
    }
}

function v37UpdateHUD() {
    const panel = systemStatusPanel;
    if (!panel) return;
    const charge = Math.max(ultimateCharge || 0, chakraBlastCharge || 0, comboEnergy || 0);
    panel.style.setProperty("--v37-charge", `${Math.min(100, Math.round(charge * 100))}%`);
    panel.classList.toggle("v37-panel-charging", chakraBlastPhase === "charging" || ultimateCharge > 0.02);
    panel.classList.toggle("v37-panel-sync", dualSyncStateText === "SYNCHRONIZED");
    v37UpdateHandLocks();
}

function v37Initialize() {
    v37InstallBackground();
    v37ApplyTheme(0);
    v37BootOverlay = document.createElement("div");
    v37BootOverlay.className = "v37-boot-overlay";
    v37BootOverlay.innerHTML = `
      <div class="v37-boot-mark">忍</div>
      <div class="v37-boot-title">NINJA SYSTEM <span>V3.7</span></div>
      <div class="v37-boot-track"><i></i></div>
      <div class="v37-boot-status">INITIALIZING HOLOGRAPHIC INTERFACE...</div>
      <div class="v37-boot-code">CHAKRA RADAR // HUD // TRACKING ARRAY</div>
    `;
    document.body.appendChild(v37BootOverlay);
    window.setTimeout(() => {
        v37BootOverlay?.classList.add("v37-boot-complete");
        v37Notify("SYSTEM ONLINE // V3.7", "system");
        window.setTimeout(() => v37BootOverlay?.remove(), 700);
    }, 2300);
}

if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", v37Initialize, { once: true });
} else {
    v37Initialize();
}

// THREE.JS INITIALIZATION
// =========================================================

function initThree() {

    if (!window.THREE) {
        throw new Error("Three.js did not load.");
    }

    renderer = new THREE.WebGLRenderer({
        canvas: fxCanvas,
        alpha: true,
        antialias: true,
        powerPreference: "high-performance"
    });

    renderer.setPixelRatio(
        Math.min(window.devicePixelRatio || 1, 1.75)
    );

    renderer.setSize(
        fxCanvas.clientWidth || 640,
        fxCanvas.clientHeight || 360,
        false
    );

    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.25;

    scene = new THREE.Scene();

    threeCamera = new THREE.PerspectiveCamera(
        42,
        640 / 360,
        0.1,
        100
    );

    threeCamera.position.set(0, 0, 8);

    scene.add(
        new THREE.AmbientLight(0xffffff, 1.15)
    );

    const keyLight = new THREE.PointLight(
        0xffa45a,
        2.2,
        12
    );

    keyLight.position.set(-2, 2, 4);
    scene.add(keyLight);

    // Independent hand-effect groups.

    for (let i = 0; i < 2; i++) {

        const group = new THREE.Group();

        group.visible = false;

        group.userData.fade = 0;
        group.userData.targetFade = 0;
        group.userData.lastLandmarks = null;
        group.userData.power = null;

        scene.add(group);

        effectGroups.push(group);
        particleSystems.push(null);

    }

    buildChakraShields();
    buildChakraConnection();
    buildAdvancedChakraAuras();
    buildChakraCloaks();
    buildDualHandFusion();
    buildComboFinisherEffect();
    buildSystemStatusInterface();

    clock = new THREE.Clock();

    rebuildAllEffects();

    buildUltimateChakra();
    buildChakraBlast();

    if (typeof ResizeObserver !== "undefined" && fxCanvas.parentElement) {
        resizeObserver = new ResizeObserver(resizeThree);
        resizeObserver.observe(fxCanvas.parentElement);
    } else {
        window.addEventListener("resize", resizeThree);
    }

    resizeThree();

    threeReady = true;

    animateThree();

}

// =========================================================
// RESIZE THREE.JS
// =========================================================

function resizeThree() {

    if (!renderer || !fxCanvas.parentElement) return;

    const rect =
        fxCanvas.parentElement.getBoundingClientRect();

    const width = Math.max(1, rect.width);
    const height = Math.max(1, rect.height);

    renderer.setSize(width, height, false);

    threeCamera.aspect = width / height;
    threeCamera.updateProjectionMatrix();

}

// =========================================================
// MATERIALS AND OBJECTS
// =========================================================

function makeGlowMaterial(color, opacity = 0.7) {

    return new THREE.MeshBasicMaterial({
        color,
        transparent: true,
        opacity,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
        side: THREE.DoubleSide
    });

}

function addSphere(
    parent,
    radius,
    color,
    opacity = 0.5,
    scale = [1, 1, 1]
) {

    const geometry = new THREE.SphereGeometry(
        radius,
        32,
        24
    );

    const mesh = new THREE.Mesh(
        geometry,
        makeGlowMaterial(color, opacity)
    );

    mesh.scale.set(...scale);
    parent.add(mesh);

    return mesh;

}

function addTorus(
    parent,
    radius,
    tube,
    color,
    opacity = 0.8
) {

    const geometry = new THREE.TorusGeometry(
        radius,
        tube,
        12,
        96
    );

    const mesh = new THREE.Mesh(
        geometry,
        makeGlowMaterial(color, opacity)
    );

    parent.add(mesh);

    return mesh;

}

// =========================================================
// PARTICLE CREATION
// =========================================================

function createParticleField(
    parent,
    count,
    color,
    spread,
    size
) {

    const positions = new Float32Array(count * 3);
    const velocities = [];

    for (let i = 0; i < count; i++) {

        positions[i * 3] =
            (Math.random() - 0.5) * spread;

        positions[i * 3 + 1] =
            (Math.random() - 0.5) * spread;

        positions[i * 3 + 2] =
            (Math.random() - 0.5) * spread;

        velocities.push({
            x: (Math.random() - 0.5) * 0.012,
            y: Math.random() * 0.018 + 0.003,
            z: (Math.random() - 0.5) * 0.012
        });

    }

    const geometry = new THREE.BufferGeometry();

    geometry.setAttribute(
        "position",
        new THREE.BufferAttribute(positions, 3)
    );

    const material = new THREE.PointsMaterial({
        color,
        size,
        transparent: true,
        opacity: 0.9,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
        sizeAttenuation: true
    });

    const points = new THREE.Points(geometry, material);

    points.userData.velocities = velocities;
    points.userData.spread = spread;

    parent.add(points);

    return points;

}

// =========================================================
// EFFECT CLEANUP
// =========================================================

function clearEffectGroup(group) {

    if (!group) return;

    while (group.children.length) {

        const child = group.children[0];

        group.remove(child);

        child.traverse?.(obj => {

            obj.geometry?.dispose?.();

            if (Array.isArray(obj.material)) {

                obj.material.forEach(
                    material => material.dispose?.()
                );

            } else {

                obj.material?.dispose?.();

            }

        });

    }

}

// =========================================================
// INDEPENDENT EFFECT BUILDING
// =========================================================

function rebuildAllEffects() {

    if (!effectGroups.length) return;

    effectGroups.forEach((group, index) => {

        const power =
            handJutsu[index] || selectedPower;

        rebuildHandEffect(index, power);

    });

}

function rebuildHandEffect(index, power) {

    const group = effectGroups[index];

    if (!group) return;

    clearEffectGroup(group);

    const previousGroup = effectGroup;
    const previousParticles = particleSystem;

    effectGroup = group;
    particleSystem = null;

    if (power) rebuildEffect(power);

    particleSystems[index] = particleSystem;
    effectPowerByHand[index] = power;

    group.userData.power = power;

    captureEffectMaterials(group);

    effectGroup = previousGroup;
    particleSystem = previousParticles;

    group.visible = group.userData.fade > 0.01;

}

function updateHandJutsu(index, power) {

    if (effectPowerByHand[index] === power) return;

    rebuildHandEffect(index, power);

}

function rebuildEffect(power) {

    if (!effectGroup) return;

    if (power === "fire") buildFireEffect();
    if (power === "rasengan") buildRasenganEffect();
    if (power === "lightning") buildChidoriEffect();
    if (power === "rasenshuriken") buildRasenshurikenEffect();

}

// =========================================================
// EFFECT FADE MATERIAL SETUP
// =========================================================

function captureEffectMaterials(group) {

    group.traverse(object => {

        if (!object.material) return;

        const materials = Array.isArray(object.material)
            ? object.material
            : [object.material];

        materials.forEach(material => {

            material.userData.baseOpacity =
                material.opacity;

            material.userData.effectOpacity = null;
            material.transparent = true;

        });

    });

}

function applyEffectFade(group, fade) {

    group.traverse(object => {

        if (!object.material) return;

        const materials = Array.isArray(object.material)
            ? object.material
            : [object.material];

        materials.forEach(material => {

            const baseOpacity =
                material.userData.effectOpacity ??
                material.userData.baseOpacity ??
                material.opacity;

            material.opacity = baseOpacity * fade;

        });

    });

}

// =========================================================
// FIRE STYLE
// =========================================================

function buildFireEffect() {

    const core = addSphere(
        effectGroup, 0.82, 0xff7a18, 0.23, [1, 1, 0.78]
    );

    core.userData.role = "core";

    const hotCore = addSphere(
        effectGroup, 0.48, 0xffd47a, 0.48, [1, 1, 0.85]
    );

    hotCore.userData.role = "hotCore";

    const whiteCore = addSphere(
        effectGroup, 0.22, 0xffffff, 0.7
    );

    whiteCore.userData.role = "whiteCore";

    for (let i = 0; i < 3; i++) {

        const shell = addSphere(
            effectGroup,
            0.9 + i * 0.13,
            i % 2 ? 0xff3d0a : 0xff9a22,
            0.075,
            [1, 1, 0.72]
        );

        shell.userData.role = "shell";
        shell.userData.phase = i * 1.7;

    }

    for (let i = 0; i < 9; i++) {

        const flame = addSphere(
            effectGroup,
            0.18 + Math.random() * 0.12,
            i % 2 ? 0xff4a0a : 0xffbd38,
            0.38,
            [0.7, 1.9, 0.7]
        );

        const angle = (i / 9) * Math.PI * 2;

        flame.position.set(
            Math.cos(angle) * 0.55,
            Math.sin(angle) * 0.55,
            (Math.random() - 0.5) * 0.3
        );

        flame.userData.role = "flame";
        flame.userData.phase = angle;

    }

    for (let i = 0; i < 4; i++) {

        const smoke = addSphere(
            effectGroup,
            0.36 + i * 0.06,
            0x56515a,
            0.12,
            [1.2, 1.4, 0.8]
        );

        smoke.position.set(
            (Math.random() - 0.5) * 1.4,
            0.8 + i * 0.18,
            -0.25
        );

        smoke.userData.role = "smoke";
        smoke.userData.phase = i * 1.3;

    }

    addTorus(effectGroup, 0.98, 0.035, 0xff9a32, 0.7);

    const ring2 = addTorus(
        effectGroup, 1.15, 0.018, 0xffdf9b, 0.55
    );

    ring2.rotation.x = 1.1;
    ring2.userData.role = "ring";
    ring2.userData.spin = -0.8;

    particleSystem = createParticleField(
        effectGroup, 260, 0xffa23a, 2.8, 0.045
    );

}

// =========================================================
// RASENGAN
// =========================================================

function buildRasenganEffect() {

    addSphere(effectGroup, 0.88, 0x087dff, 0.2, [1, 1, 0.9]);
    addSphere(effectGroup, 0.62, 0x36cfff, 0.24, [1, 1, 0.9]);
    addSphere(effectGroup, 0.28, 0xe8ffff, 0.65);

    for (let i = 0; i < 8; i++) {

        const ring = addTorus(
            effectGroup,
            0.7 + (i % 3) * 0.12,
            0.018 + (i % 2) * 0.012,
            i % 2 ? 0x8cecff : 0xffffff,
            0.72
        );

        ring.rotation.set(
            Math.random() * Math.PI,
            Math.random() * Math.PI,
            Math.random() * Math.PI
        );

        ring.userData.role = "chakraRing";

        ring.userData.spin =
            (i % 2 ? 1 : -1) * (0.45 + i * 0.08);

    }

    for (let i = 0; i < 5; i++) {

        const stream = addTorus(
            effectGroup,
            0.9 + i * 0.045,
            0.012,
            0x38bfff,
            0.48
        );

        stream.rotation.set(i * 0.6, i * 0.8, i * 0.3);
        stream.userData.role = "stream";
        stream.userData.spin = 1.1 + i * 0.2;

    }

    particleSystem = createParticleField(
        effectGroup, 220, 0x9beeff, 2.4, 0.035
    );

}

// =========================================================
// CHIDORI — V3.5 FLOWING LIGHTNING REFINEMENT
// =========================================================

function buildChidoriEffect() {
    // Kakashi-inspired Chidori: a compact palm charge with a directional
    // stream of dense, branching blue lightning. It is intentionally NOT
    // a sphere, ring, or rotating shell.
    const mainBolts = 20;

    for (let i = 0; i < mainBolts; i++) {
        const lane = (i / (mainBolts - 1)) * 2 - 1;
        const length = 2.15 + Math.random() * 1.15;
        const spread = lane * (0.12 + Math.random() * 0.22);
        const points = [];
        const segments = 17;

        for (let j = 0; j <= segments; j++) {
            const t = j / segments;
            const x = 0.08 + length * t;
            const envelope = 0.025 + t * 0.20;
            const y = spread * t + (j === 0 || j === segments ? 0 : (Math.random() - 0.5) * envelope);
            const z = (Math.random() - 0.5) * (0.04 + t * 0.16);
            points.push(new THREE.Vector3(x, y, z));
        }

        const geometry = new THREE.BufferGeometry().setFromPoints(points);
        [
            { color: 0x004bff, opacity: 0.30, role: "chidoriGlowBolt" },
            { color: 0x087cff, opacity: 0.82, role: "chidoriBlueBolt" },
            { color: 0x55caff, opacity: i % 4 === 0 ? 0.62 : 0.30, role: "chidoriWhiteBolt" }
        ].forEach(layer => {
            const line = new THREE.Line(geometry.clone(), new THREE.LineBasicMaterial({
                color: layer.color,
                transparent: true,
                opacity: layer.opacity,
                blending: THREE.AdditiveBlending,
                depthWrite: false
            }));
            line.userData.role = layer.role;
            line.userData.phase = i * 0.39;
            line.userData.speed = 1.8 + (i % 5) * 0.45;
            line.userData.baseOpacity = layer.opacity;
            line.userData.seed = i;
            effectGroup.add(line);
        });

        // Forks branch from the main stream, not around the palm.
        if (i % 2 === 0) {
            const branchStart = 0.35 + Math.random() * 0.42;
            const branchSide = i % 4 === 0 ? 1 : -1;
            const branchLength = 0.48 + Math.random() * 0.48;
            const branchPoints = [
                new THREE.Vector3(0.08 + length * branchStart, spread * branchStart, 0.015),
                new THREE.Vector3(0.08 + length * (branchStart + 0.10), spread * branchStart + branchSide * 0.12, 0.025),
                new THREE.Vector3(0.08 + length * branchStart + branchLength, spread * branchStart + branchSide * branchLength, -0.015),
                new THREE.Vector3(0.08 + length * branchStart + branchLength * 1.18, spread * branchStart + branchSide * branchLength * 1.2, 0.01)
            ];
            const branchGeometry = new THREE.BufferGeometry().setFromPoints(branchPoints);
            const branch = new THREE.Line(branchGeometry, new THREE.LineBasicMaterial({
                color: 0x168cff,
                transparent: true,
                opacity: 0.76,
                blending: THREE.AdditiveBlending,
                depthWrite: false
            }));
            branch.userData.role = "chidoriBlueBolt";
            branch.userData.phase = i * 0.51;
            branch.userData.baseOpacity = 0.76;
            effectGroup.add(branch);
        }
    }

    // Small, flattened blue-white origin at the palm.
    const palmGlow = addSphere(effectGroup, 0.17, 0x006bff, 0.68, [1.0, 0.48, 0.38]);
    palmGlow.userData.role = "chidoriPalmFlash";
    const palmCore = addSphere(effectGroup, 0.075, 0x9bdcff, 0.92, [1.0, 0.42, 0.34]);
    palmCore.userData.role = "chidoriPalmFlash";

    // Narrow streaks and sparks follow the direction of the lightning.
    particleSystem = createParticleField(effectGroup, 260, 0x168cff, 3.0, 0.022);
}


// =========================================================
// RASENSHURIKEN — WIND-STYLE CHAKRA DISC (VISUAL EFFECT)
// A spinning four-blade chakra silhouette with wind trails.
// =========================================================
function buildRasenshurikenEffect() {
    // Rasenshuriken redesign: a classic dense Rasengan orb with a clearly
    // visible four-blade wind shuriken rotating INSIDE the chakra sphere.

    // Rasengan body — layered blue chakra volume.
    const outerOrb = addSphere(effectGroup, 0.98, 0x087dff, 0.22, [1, 1, 0.92]);
    outerOrb.userData.role = "rasenshurikenOrb";
    const middleOrb = addSphere(effectGroup, 0.78, 0x19aaff, 0.20, [1, 1, 0.92]);
    middleOrb.userData.role = "rasenshurikenOrb";
    const innerOrb = addSphere(effectGroup, 0.48, 0x54dfff, 0.16, [1, 1, 0.9]);
    innerOrb.userData.role = "rasenshurikenOrb";

    // Rasengan's swirling chakra surface, kept restrained so the silhouette
    // of the shuriken remains easy to see.
    for (let i = 0; i < 4; i++) {
        const stream = addTorus(
            effectGroup,
            0.72 + i * 0.075,
            0.018,
            i % 2 ? 0x8cecff : 0x2aaeff,
            0.38
        );
        stream.rotation.set(0.45 + i * 0.38, 0.55 + i * 0.42, i * 0.7);
        stream.userData.role = "rasenshurikenOrbStream";
        stream.userData.spin = i % 2 ? -0.9 : 0.75;
    }

    // A single rotor holds four curved blades. Each blade has a broad root
    // and a sharp swept tip, making a readable four-point wind shuriken.
    const rotor = new THREE.Group();
    rotor.position.set(0, 0, 0.48);
    rotor.userData.role = "rasenshurikenRotor";
    rotor.userData.spin = 3.15;
    effectGroup.add(rotor);

    const bladeShape = new THREE.Shape();
    bladeShape.moveTo(0.02, 0.10);
    bladeShape.quadraticCurveTo(0.23, 0.25, 0.91, 0.88);
    bladeShape.quadraticCurveTo(0.77, 0.43, 0.43, 0.18);
    bladeShape.quadraticCurveTo(0.20, 0.04, 0.02, 0.10);
    const bladeGeometry = new THREE.ShapeGeometry(bladeShape, 24);

    for (let i = 0; i < 4; i++) {
        const blade = new THREE.Mesh(
            bladeGeometry,
            new THREE.MeshBasicMaterial({
                color: i % 2 ? 0x25bfff : 0x9af5ff,
                transparent: true,
                opacity: 0.86,
                side: THREE.DoubleSide,
                blending: THREE.AdditiveBlending,
                depthWrite: false
            })
        );
        blade.rotation.z = i * Math.PI / 2;
        blade.position.z = (i % 2) * 0.012;
        blade.userData.role = "rasenshurikenBlade";
        blade.userData.phase = i * 0.8;
        rotor.add(blade);

        // Fine bright edge makes each curved blade read against the orb.
        const edgePoints = [
            new THREE.Vector3(0.02, 0.10, 0.025),
            new THREE.Vector3(0.23, 0.25, 0.025),
            new THREE.Vector3(0.91, 0.88, 0.025),
            new THREE.Vector3(0.77, 0.43, 0.025),
            new THREE.Vector3(0.43, 0.18, 0.025)
        ];
        const edge = new THREE.Line(
            new THREE.BufferGeometry().setFromPoints(edgePoints),
            new THREE.LineBasicMaterial({
                color: 0xd8fbff,
                transparent: true,
                opacity: 0.92,
                blending: THREE.AdditiveBlending,
                depthWrite: false
            })
        );
        edge.rotation.z = i * Math.PI / 2;
        rotor.add(edge);
    }

    // Bright center hub visually locks the four blades together.
    const hubGlow = addSphere(rotor, 0.23, 0x13aaff, 0.58, [1, 1, 0.42]);
    hubGlow.position.z = 0.045;
    const hub = addSphere(rotor, 0.105, 0xe8ffff, 0.96, [1, 1, 0.5]);
    hub.position.z = 0.07;

    // Small wind wisps orbit the orb rather than forming a tangled cage.
    for (let i = 0; i < 8; i++) {
        const angle = (i / 8) * Math.PI * 2;
        const points = [];
        for (let j = 0; j <= 10; j++) {
            const t = j / 10;
            const a = angle + t * 0.52;
            const r = 0.98 + Math.sin(t * Math.PI) * 0.08;
            points.push(new THREE.Vector3(Math.cos(a) * r, Math.sin(a) * r, -0.10));
        }
        const wisp = new THREE.Line(
            new THREE.BufferGeometry().setFromPoints(points),
            new THREE.LineBasicMaterial({
                color: i % 2 ? 0x38bfff : 0xb9f7ff,
                transparent: true,
                opacity: 0.30,
                blending: THREE.AdditiveBlending,
                depthWrite: false
            })
        );
        wisp.userData.role = "rasenshurikenWindWisp";
        wisp.userData.phase = i * 0.7;
        effectGroup.add(wisp);
    }

    particleSystem = createParticleField(effectGroup, 220, 0x79e7ff, 2.35, 0.03);
}


function createLightningArc(innerRadius, outerRadius) {

    const points = [];
    const segments = 12;
    const angle = Math.random() * Math.PI * 2;

    for (let i = 0; i <= segments; i++) {

        const p = i / segments;

        const radius =
            innerRadius + p * (outerRadius - innerRadius);

        const a =
            angle + (Math.random() - 0.5) * 0.65;

        points.push(
            new THREE.Vector3(
                Math.cos(a) * radius,
                Math.sin(a) * radius,
                (Math.random() - 0.5) * 0.5
            )
        );

    }

    const geometry = new THREE.BufferGeometry()
        .setFromPoints(points);

    const material = new THREE.LineBasicMaterial({
        color: Math.random() > 0.5 ? 0xffffff : 0x69baff,
        transparent: true,
        opacity: 0.95,
        blending: THREE.AdditiveBlending
    });

    return new THREE.Line(geometry, material);

}

// =========================================================
// ADVANCED CHAKRA AURA

function buildAdvancedChakraAuras() {
    chakraAuraGroups = [];

    for (let i = 0; i < 2; i++) {
        const aura = new THREE.Group();
        aura.visible = false;
        aura.userData.fade = 0;
        aura.userData.targetFade = 0;
        aura.userData.lastLandmarks = null;

        addSphere(aura, 1.18, 0x168cff, 0.10, [1, 1, 0.78]).userData.role = "auraOuter";
        addSphere(aura, 0.78, 0x78e8ff, 0.12, [1, 1, 0.9]).userData.role = "auraInner";

        for (let j = 0; j < 4; j++) {
            const ring = addTorus(aura, 0.92 + j * 0.12, 0.014,
                j % 2 ? 0x9ceeff : 0xffffff, 0.48);
            ring.rotation.set(j * 0.55, j * 0.8, j * 0.35);
            ring.userData.role = "auraRing";
            ring.userData.spin = j % 2 ? 1.4 : -1.2;
        }

        aura.userData.particles = createParticleField(aura, 100, 0x8cecff, 2.2, 0.028);
        scene.add(aura);
        captureEffectMaterials(aura);
        chakraAuraGroups.push(aura);
    }
}

function animateAdvancedChakraAuras(delta, time) {
    chakraAuraGroups.forEach((aura, index) => {
        const landmarks = detectedHands[index] || null;
        if (landmarks) aura.userData.lastLandmarks = landmarks;

        const active = Boolean(landmarks) && (Boolean(handJutsu[index]) || ultimateActive);
        aura.userData.targetFade = active ? 1 : 0;
        aura.userData.fade += (aura.userData.targetFade - aura.userData.fade) * Math.min(1, delta * 6);

        if (aura.userData.fade < 0.01 && !active) {
            aura.visible = false;
            return;
        }

        const palm = getPalmPosition(aura.userData.lastLandmarks);
        if (!palm) {
            aura.visible = false;
            return;
        }

        const vh = 2 * threeCamera.position.z * Math.tan(THREE.MathUtils.degToRad(threeCamera.fov / 2));
        const vw = vh * threeCamera.aspect;
        aura.position.set(palm.x * vw / 2, palm.y * vh / 2, -0.12);
        aura.scale.setScalar(palm.radius * (1.12 + Math.sin(time * 5 + index) * 0.035));
        aura.visible = true;

        aura.children.forEach(child => {
            if (child.userData.role === "auraRing") {
                child.rotation.x += delta * child.userData.spin;
                child.rotation.y += delta * child.userData.spin * 0.7;
                child.rotation.z += delta * 0.25;
            }
            if (child.userData.role === "auraOuter") child.material.userData.effectOpacity = 0.08 + Math.sin(time * 4 + index) * 0.025;
            if (child.userData.role === "auraInner") child.material.userData.effectOpacity = 0.09 + Math.sin(time * 7 + index) * 0.035;
        });

        updateParticles(aura.userData.particles, delta, time);
        applyEffectFade(aura, aura.userData.fade);
    });
}

// DUAL-HAND RASENGAN FUSION


// =========================================================
// V3.5 — DUAL-HAND CHAKRA CLOAK
// Hand-following chakra mantle with rotating energy rings.
// This is a visual effect only; it uses the existing hand tracker.
// =========================================================

function buildChakraCloaks() {
    chakraCloakGroups = [];
    chakraCloakParticles = [];
    chakraCloakRings = [[], []];

    for (let handIndex = 0; handIndex < 2; handIndex++) {
        const group = new THREE.Group();
        group.visible = false;
        group.userData.fade = 0;
        group.userData.targetFade = 0;
        group.userData.lastPosition = new THREE.Vector3(0, 0, 0);
        group.userData.lastScale = 1;

        const mantle = addSphere(
            group, 0.78, 0x087dff, 0.13, [1.0, 1.0, 0.72]
        );
        mantle.userData.role = "cloakMantle";

        const innerGlow = addSphere(
            group, 0.48, 0x70eaff, 0.18, [1.0, 1.0, 0.78]
        );
        innerGlow.userData.role = "cloakInnerGlow";

        const rings = [];
        for (let ringIndex = 0; ringIndex < 4; ringIndex++) {
            const ring = addTorus(
                group,
                0.88 + ringIndex * 0.11,
                0.018 + (ringIndex % 2) * 0.008,
                ringIndex % 2 ? 0x9beeff : 0x2b8dff,
                0.48
            );
            ring.rotation.set(
                ringIndex * 0.72,
                ringIndex * 0.43,
                ringIndex * 0.88
            );
            ring.userData.spin = ringIndex % 2 ? 1.9 : -2.4;
            ring.userData.phase = ringIndex * 1.7;
            rings.push(ring);
        }

        const particles = createParticleField(
            group, 150, 0x78e4ff, 1.9, 0.026
        );

        scene.add(group);
        captureEffectMaterials(group);

        chakraCloakGroups.push(group);
        chakraCloakParticles.push(particles);
        chakraCloakRings[handIndex] = rings;
    }
}

function animateChakraCloaks(delta, time) {
    if (!chakraCloakGroups.length || !threeCamera) return;

    const viewHeight = 2 * threeCamera.position.z *
        Math.tan(THREE.MathUtils.degToRad(threeCamera.fov / 2));
    const viewWidth = viewHeight * threeCamera.aspect;

    for (let i = 0; i < chakraCloakGroups.length; i++) {
        const group = chakraCloakGroups[i];
        const landmarks = detectedHands[i];
        const palm = landmarks ? getPalmPosition(landmarks) : null;
        const active = Boolean(palm) && (Boolean(handJutsu[i]) || ultimateActive);

        group.userData.targetFade = active ? 1 : 0;
        group.userData.fade +=
            (group.userData.targetFade - group.userData.fade) *
            Math.min(1, delta * 5.5);

        if (palm) {
            group.userData.lastPosition.set(
                palm.x * viewWidth / 2,
                palm.y * viewHeight / 2,
                0.28
            );
            group.userData.lastScale = THREE.MathUtils.clamp(
                palm.radius * 0.78,
                0.62,
                1.42
            );
        }

        const fade = group.userData.fade;
        if (fade < 0.012 && group.userData.targetFade === 0) {
            group.visible = false;
            continue;
        }

        group.visible = true;
        group.position.copy(group.userData.lastPosition);

        const ultimateBoost = ultimateActive ? 1.18 : 1;
        const pulse = 1 + Math.sin(time * 8.5 + i * 1.4) * 0.055;
        group.scale.setScalar(group.userData.lastScale * pulse * ultimateBoost);

        chakraCloakRings[i].forEach((ring, ringIndex) => {
            const speedBoost = ultimateActive ? 1.65 : 1;
            ring.rotation.x += delta * ring.userData.spin * 0.42 * speedBoost;
            ring.rotation.y += delta * ring.userData.spin * 0.7 * speedBoost;
            ring.rotation.z += delta * ring.userData.spin * speedBoost;
            ring.material.userData.effectOpacity =
                0.2 + fade * (0.28 + (Math.sin(time * 7 + ring.userData.phase) + 1) * 0.13);
        });

        group.children.forEach(child => {
            if (child.userData.role === "cloakMantle") {
                child.material.userData.effectOpacity =
                    0.08 + fade * (ultimateActive ? 0.28 : 0.19);
                child.scale.setScalar(1 + Math.sin(time * 6 + i) * 0.055);
            }
            if (child.userData.role === "cloakInnerGlow") {
                child.material.userData.effectOpacity =
                    0.1 + fade * (ultimateActive ? 0.36 : 0.22);
            }
        });

        applyEffectFade(group, fade);
        updateParticles(chakraCloakParticles[i], delta, time + i * 1.3);
    }
}

function updateChakraEvolutionHUD() {
    const ultimatePercent = Math.round(ultimateCharge * 100);
    const blastPercent = Math.round(chakraBlastCharge * 100);

    const ultimateFill = document.getElementById("ultimateModeFill");
    const blastFill = document.getElementById("blastEvolutionFill");
    const ultimateText = document.getElementById("ultimateModeText");
    const blastText = document.getElementById("blastEvolutionText");
    const cloakStatus = document.getElementById("cloakStatus");
    const note = document.getElementById("evolutionNote");

    if (ultimateFill) ultimateFill.style.width = `${ultimatePercent}%`;
    if (blastFill) blastFill.style.width = `${blastPercent}%`;
    if (ultimateText) ultimateText.textContent = `${ultimatePercent}%`;
    if (blastText) blastText.textContent = `${blastPercent}%`;

    const cloakActive = detectedHands.some((_, index) =>
        Boolean(handJutsu[index])
    ) || (ultimateActive && detectedHands.length > 0);

    if (cloakStatus) {
        cloakStatus.textContent = ultimateActive
            ? "ULTIMATE CLOAK"
            : cloakActive ? "CHAKRA CLOAK ACTIVE" : "CLOAK STANDBY";
    }

    if (note) {
        note.textContent = ultimateActive
            ? "Ultimate Mode is amplifying the hand chakra cloak."
            : chakraBlastPhase === "charging"
                ? "Both palms are charging the Ultimate Chakra Blast. Close both fists to release."
                : cloakActive
                    ? "Chakra cloak synchronized with your active hand technique."
                    : "Activate a technique with a fist gesture to awaken the hand chakra cloak.";
    }
}


function buildDualHandFusion() {
    fusionGroup = new THREE.Group();
    fusionGroup.visible = false;

    // Two visible source spheres feed one larger central fusion core.
    const leftSource = addSphere(fusionGroup, 0.30, 0x159dff, 0.72, [0.82, 0.82, 0.82]);
    leftSource.position.set(-0.92, 0, 0);
    leftSource.userData.role = "fusionSource";
    const rightSource = addSphere(fusionGroup, 0.30, 0x159dff, 0.72, [0.82, 0.82, 0.82]);
    rightSource.position.set(0.92, 0, 0);
    rightSource.userData.role = "fusionSource";

    fusionCore = addSphere(fusionGroup, 0.66, 0x168cff, 0.48);
    fusionCore.userData.role = "fusionMainCore";
    const innerCore = addSphere(fusionGroup, 0.27, 0xdaf7ff, 0.82);
    innerCore.userData.role = "fusionWhiteCore";

    // Curved energy filaments visibly connect both source spheres to the core.
    for (let i = 0; i < 18; i++) {
        const side = i % 2 ? 1 : -1;
        const z = (Math.random() - 0.5) * 0.34;
        const bend = (Math.random() - 0.5) * 0.48;
        const points = [
            new THREE.Vector3(-0.88, 0, z),
            new THREE.Vector3(-0.48, bend, z + 0.04),
            new THREE.Vector3(0.0, bend * 0.35, z - 0.03),
            new THREE.Vector3(0.48, -bend, z + 0.04),
            new THREE.Vector3(0.88, 0, z)
        ];
        const filament = new THREE.Line(
            new THREE.BufferGeometry().setFromPoints(points),
            new THREE.LineBasicMaterial({
                color: i % 3 === 0 ? 0xdaf7ff : 0x168cff,
                transparent: true,
                opacity: 0.72,
                blending: THREE.AdditiveBlending,
                depthWrite: false
            })
        );
        filament.userData.role = "fusionStream";
        filament.userData.phase = i * 0.37;
        filament.userData.side = side;
        fusionGroup.add(filament);
    }

    fusionRings = [];
    for (let i = 0; i < 7; i++) {
        const ring = addTorus(fusionGroup, 0.72 + i * 0.065, 0.012,
            i % 2 ? 0x168cff : 0x9ceaff, 0.58);
        ring.rotation.set(i * 0.37, i * 0.61, i * 0.23);
        ring.userData.spin = i % 2 ? 2.1 : -1.8;
        fusionRings.push(ring);
    }

    fusionParticles = createParticleField(fusionGroup, 300, 0x42bfff, 3.2, 0.03);
    scene.add(fusionGroup);
    captureEffectMaterials(fusionGroup);
}

function animateDualHandFusion(delta, time) {
    if (!fusionGroup || detectedHands.length !== 2 ||
        handJutsu[0] !== "rasengan" || handJutsu[1] !== "rasengan") {
        if (fusionGroup) fusionGroup.visible = false;
        return;
    }

    const a = getPalmPosition(detectedHands[0]);
    const b = getPalmPosition(detectedHands[1]);
    if (!a || !b) {
        fusionGroup.visible = false;
        return;
    }

    const distance = Math.hypot(a.x - b.x, a.y - b.y);
    if (distance > 1.35) {
        fusionGroup.visible = false;
        return;
    }

    const vh = 2 * threeCamera.position.z * Math.tan(THREE.MathUtils.degToRad(threeCamera.fov / 2));
    const vw = vh * threeCamera.aspect;
    fusionGroup.position.set((a.x + b.x) * vw / 4, (a.y + b.y) * vh / 4, 0.35);

    const approach = THREE.MathUtils.clamp((1.35 - distance) / 0.95, 0, 1);
    const pulse = 1 + Math.sin(time * 8.5) * 0.035;
    fusionGroup.scale.setScalar((0.62 + approach * 0.82) * pulse);
    // Fusion 2.0: source spheres visibly travel inward as the hands converge.
    fusionGroup.children.forEach(child => {
        if (child.userData.role === "fusionSource") {
            const side = child.position.x < 0 ? -1 : 1;
            child.position.x = side * (0.92 - approach * 0.48);
            child.position.y = Math.sin(time * 8 + side) * (0.05 + approach * 0.08);
        }
    });
    fusionGroup.visible = true;

    fusionRings.forEach(ring => {
        ring.rotation.x += delta * ring.userData.spin;
        ring.rotation.y -= delta * ring.userData.spin * 0.8;
        ring.rotation.z += delta * 0.6;
        ring.material.userData.effectOpacity = 0.32 + approach * 0.42;
    });

    fusionGroup.children.forEach(child => {
        const role = child.userData.role;
        if (role === "fusionSource") {
            const sourcePulse = 1 + Math.sin(time * 12 + child.position.x) * 0.12;
            child.scale.setScalar(sourcePulse);
            child.material.userData.effectOpacity = 0.55 + approach * 0.32;
        } else if (role === "fusionStream") {
            child.material.userData.effectOpacity =
                0.28 + approach * 0.55 + (Math.sin(time * 15 + child.userData.phase) + 1) * 0.10;
        } else if (role === "fusionMainCore") {
            const corePulse = 1 + Math.sin(time * 10) * 0.08;
            child.scale.setScalar(corePulse);
            child.material.userData.effectOpacity = 0.34 + approach * 0.46;
        } else if (role === "fusionWhiteCore") {
            child.material.userData.effectOpacity = 0.55 + approach * 0.38;
        }
    });

    fusionCore.material.userData.effectOpacity = 0.38 + approach * 0.42;
    updateParticles(fusionParticles, delta, time);
    applyEffectFade(fusionGroup, 1);
}


// DUAL-HAND CHAKRA SHIELD SYSTEM
// =========================================================

function buildChakraShields() {

    chakraShieldGroups = [];

    for (let i = 0; i < 2; i++) {

        const shield = new THREE.Group();

        shield.visible = false;

        shield.userData.fade = 0;
        shield.userData.targetFade = 0;
        shield.userData.lastLandmarks = null;
        shield.userData.particles = null;

        const shellGeometry = new THREE.SphereGeometry(
            1.08, 48, 32
        );

        const shellMaterial = new THREE.MeshBasicMaterial({
            color: SHIELD_COLORS.default,
            transparent: true,
            opacity: 0.09,
            side: THREE.DoubleSide,
            blending: THREE.AdditiveBlending,
            depthWrite: false
        });

        const shell = new THREE.Mesh(
            shellGeometry,
            shellMaterial
        );

        shell.userData.role = "shieldShell";
        shield.add(shell);

        const innerGeometry = new THREE.SphereGeometry(
            0.88, 32, 24
        );

        const innerMaterial = new THREE.MeshBasicMaterial({
            color: SHIELD_COLORS.default,
            transparent: true,
            opacity: 0.035,
            wireframe: true,
            blending: THREE.AdditiveBlending,
            depthWrite: false
        });

        const innerLayer = new THREE.Mesh(
            innerGeometry,
            innerMaterial
        );

        innerLayer.userData.role = "shieldInner";
        shield.add(innerLayer);

        const lattice = new THREE.Mesh(
            new THREE.IcosahedronGeometry(0.98, 2),
            new THREE.MeshBasicMaterial({
                color: SHIELD_COLORS.default, wireframe: true,
                transparent: true, opacity: 0.13,
                blending: THREE.AdditiveBlending, depthWrite: false
            })
        );
        lattice.userData.role = "shieldLattice";
        shield.add(lattice);

        // Animated hexagonal chakra pattern wrapped around the shield.
        const hexGrid = new THREE.Group();
        hexGrid.userData.role = "shieldHexGrid";
        const hexRadius = 0.155;
        const hexPoints = [];
        for (let k = 0; k < 6; k++) {
            const angle = (Math.PI / 3) * k;
            hexPoints.push(new THREE.Vector3(
                Math.cos(angle) * hexRadius,
                Math.sin(angle) * hexRadius,
                0
            ));
        }
        const hexGeometry = new THREE.BufferGeometry().setFromPoints(hexPoints);
        for (let h = 0; h < 26; h++) {
            const y = 1 - (h / 25) * 2;
            const radial = Math.sqrt(Math.max(0, 1 - y * y));
            const theta = h * Math.PI * (3 - Math.sqrt(5));
            const normal = new THREE.Vector3(
                Math.cos(theta) * radial,
                y,
                Math.sin(theta) * radial
            ).normalize();
            const hexMaterial = new THREE.LineBasicMaterial({
                color: SHIELD_COLORS.default,
                transparent: true,
                opacity: 0.42,
                blending: THREE.AdditiveBlending,
                depthWrite: false
            });
            const hex = new THREE.LineLoop(hexGeometry, hexMaterial);
            hex.position.copy(normal).multiplyScalar(1.095);
            hex.quaternion.setFromUnitVectors(
                new THREE.Vector3(0, 0, 1), normal
            );
            hex.userData.role = "shieldHexTile";
            hexGrid.add(hex);
        }
        shield.add(hexGrid);

        for (let j = 0; j < 3; j++) {

            const ring = addTorus(
                shield,
                0.96 + j * 0.12,
                0.018,
                SHIELD_COLORS.default,
                0.5
            );

            ring.rotation.set(
                j * 0.9,
                j * 0.65,
                j * 0.75
            );

            ring.userData.role = "shieldRing";
            ring.userData.spin =
                j % 2 === 0 ? 1.5 : -1.7;

        }

        const particles = createParticleField(
            shield, 90, SHIELD_COLORS.default, 2.1, 0.025
        );

        particles.userData.role = "shieldParticles";
        shield.userData.particles = particles;

        scene.add(shield);

        captureEffectMaterials(shield);

        chakraShieldGroups.push(shield);

    }

}

// =========================================================
// SHIELD COLOUR
// =========================================================

function getChakraShieldColor(index) {

    if (ultimateActive) return SHIELD_COLORS.ultimate;

    const power =
        handJutsu[index] || effectPowerByHand[index];

    if (power === "fire") return SHIELD_COLORS.fire;
    if (power === "rasengan") return SHIELD_COLORS.rasengan;
    if (power === "lightning") return SHIELD_COLORS.lightning;
    if (power === "rasenshuriken") return SHIELD_COLORS.rasenshuriken;

    return SHIELD_COLORS.default;

}

// =========================================================
// SHIELD ANIMATION
// =========================================================

function animateChakraShields(delta, time) {

    for (let i = 0; i < chakraShieldGroups.length; i++) {

        const shield = chakraShieldGroups[i];
        const landmarks = detectedHands[i] || null;

        if (landmarks) {
            shield.userData.lastLandmarks = landmarks;
        }

        const jutsuActive =
            effectGroups[i] &&
            effectGroups[i].userData.targetFade > 0;

        const shieldActive =
            Boolean(landmarks) &&
            (jutsuActive || ultimateActive);

        shield.userData.targetFade =
            shieldActive ? 1 : 0;

        shield.userData.fade +=
            (shield.userData.targetFade - shield.userData.fade) *
            Math.min(1, delta * 7);

        const fade = shield.userData.fade;

        if (fade < 0.01 && shield.userData.targetFade === 0) {
            shield.visible = false;
            continue;
        }

        const palm = getPalmPosition(
            shield.userData.lastLandmarks
        );

        if (!palm) {
            shield.visible = false;
            continue;
        }

        shield.visible = true;

        const viewHeight =
            2 * threeCamera.position.z *
            Math.tan(
                THREE.MathUtils.degToRad(threeCamera.fov / 2)
            );

        const viewWidth =
            viewHeight * threeCamera.aspect;

        shield.position.set(
            palm.x * viewWidth / 2,
            palm.y * viewHeight / 2,
            0.18
        );

        const powerBoost = jutsuActive ? 1.08 : 1;
        const ultimateBoost = ultimateActive ? 1.18 : 1;

        const pulse =
            1 + Math.sin(time * 5 + i) * 0.035;

        shield.scale.setScalar(
            palm.radius * 0.82 *
            powerBoost * ultimateBoost * pulse
        );

        const color = getChakraShieldColor(i);
        const intensity = ultimateActive ? 1.5 : 1;

        shield.children.forEach(child => {

            const role = child.userData.role;

            if (role === "shieldShell") {

                child.rotation.y += delta * 0.22;
                child.rotation.x += delta * 0.12;

                child.material.color.setHex(color);

                child.material.userData.effectOpacity =
                    0.065 *
                    (1 + Math.sin(time * 5 + i) * 0.18) *
                    intensity;

            }

            if (role === "shieldLattice") {
                child.rotation.x += delta * 0.32;
                child.rotation.y -= delta * 0.48;
                child.material.color.setHex(color);
                child.material.userData.effectOpacity = 0.11 * intensity;
            }

            if (role === "shieldHexGrid") {
                child.rotation.y += delta * 0.12;
                child.rotation.x -= delta * 0.08;
                child.children.forEach((hex, hexIndex) => {
                    hex.material.color.setHex(color);
                    hex.material.opacity =
                        (0.30 + Math.sin(time * 3.2 + hexIndex * 0.55) * 0.12) * intensity;
                });
            }

            if (role === "shieldInner") {

                child.rotation.y -= delta * 0.55;
                child.rotation.z += delta * 0.35;

                child.scale.setScalar(
                    1 + Math.sin(time * 7 + i) * 0.035
                );

                child.material.color.setHex(color);
                child.material.userData.effectOpacity =
                    0.035 * intensity;

            }

            if (role === "shieldRing") {

                child.rotation.x +=
                    delta * child.userData.spin;

                child.rotation.y +=
                    delta * child.userData.spin * 0.65;

                child.rotation.z += delta * 0.35;

                child.material.color.setHex(color);

                child.material.userData.effectOpacity =
                    (
                        0.32 +
                        Math.sin(time * 6 + child.id) * 0.12
                    ) * intensity;

            }

            if (role === "shieldParticles") {

                child.material.color.setHex(color);

                child.material.size =
                    ultimateActive ? 0.034 : 0.025;

                child.rotation.y += delta * 0.35;

            }

        });

        updateParticles(shield.userData.particles, delta, time);
        applyEffectFade(shield, fade);

    }

}

// =========================================================
// CHAKRA LIGHTNING CONNECTION
// =========================================================

function buildChakraConnection() {

    chakraLinkGroup = new THREE.Group();
    chakraLinkGroup.visible = false;

    chakraLinkCore = new THREE.Mesh(
        new THREE.CylinderGeometry(
            0.035, 0.035, 1, 16
        ),
        makeGlowMaterial(
            CHAKRA_LINK_COLORS.default, 0.95
        )
    );

    chakraLinkGroup.add(chakraLinkCore);

    chakraLinkGlow = new THREE.Mesh(
        new THREE.CylinderGeometry(
            0.105, 0.105, 1, 16
        ),
        makeGlowMaterial(
            CHAKRA_LINK_COLORS.default, 0.28
        )
    );

    chakraLinkGroup.add(chakraLinkGlow);

    const branchCount = 18;

    const branchGeometry = new THREE.BufferGeometry();

    branchGeometry.setAttribute(
        "position",
        new THREE.BufferAttribute(
            new Float32Array(branchCount * 6), 3
        )
    );

    const branchMaterial = new THREE.LineBasicMaterial({
        color: CHAKRA_LINK_COLORS.default,
        transparent: true,
        opacity: 0.95,
        blending: THREE.AdditiveBlending,
        depthWrite: false
    });

    chakraLinkBranches = new THREE.LineSegments(
        branchGeometry,
        branchMaterial
    );

    chakraLinkBranches.userData.branchCount = branchCount;

    chakraLinkGroup.add(chakraLinkBranches);

    chakraLinkPulses = [];

    for (let i = 0; i < 5; i++) {

        const pulse = addSphere(
            chakraLinkGroup,
            0.075,
            CHAKRA_LINK_COLORS.default,
            0.95
        );

        pulse.userData.phase = i / 5;
        pulse.userData.speed =
            0.65 + Math.random() * 0.25;

        chakraLinkPulses.push(pulse);

    }

    scene.add(chakraLinkGroup);
    captureEffectMaterials(chakraLinkGroup);

}

// =========================================================
// CONNECTION COLOUR
// =========================================================

function getChakraConnectionColor() {

    if (ultimateActive) return CHAKRA_LINK_COLORS.ultimate;

    const firstPower = handJutsu[0];
    const secondPower = handJutsu[1];

    if (
        firstPower === "lightning" ||
        secondPower === "lightning"
    ) return CHAKRA_LINK_COLORS.lightning;

    if (
        firstPower === "fire" ||
        secondPower === "fire"
    ) return CHAKRA_LINK_COLORS.fire;

    if (
        firstPower === "rasenshuriken" ||
        secondPower === "rasenshuriken"
    ) return CHAKRA_LINK_COLORS.rasenshuriken;

    if (
        firstPower === "rasengan" ||
        secondPower === "rasengan"
    ) return CHAKRA_LINK_COLORS.rasengan;

    return CHAKRA_LINK_COLORS.default;

}

// =========================================================
// UPDATE ELECTRIC BRANCHES
// =========================================================

function updateChakraBranches(time, length) {

    if (!chakraLinkBranches) return;

    const attribute =
        chakraLinkBranches.geometry.attributes.position;

    const branchCount =
        chakraLinkBranches.userData.branchCount;

    for (let i = 0; i < branchCount; i++) {

        const y = (Math.random() - 0.5) * length;

        const offsetX = (Math.random() - 0.5) * 0.42;
        const offsetZ = (Math.random() - 0.5) * 0.3;

        const wave = Math.sin(time * 18 + i * 2.1) * 0.08;

        attribute.setXYZ(
            i * 2,
            wave * 0.25,
            y,
            0
        );

        attribute.setXYZ(
            i * 2 + 1,
            offsetX + wave,
            THREE.MathUtils.clamp(
                y + (Math.random() - 0.5) * 0.38,
                -length / 2,
                length / 2
            ),
            offsetZ
        );

    }

    attribute.needsUpdate = true;

}

// =========================================================
// CONNECTION ANIMATION
// =========================================================

function animateChakraConnection(delta, time) {

    if (!chakraLinkGroup) return;

    const bothHandsDetected =
        detectedHands.length === 2;

    chakraLinkTargetFade =
        bothHandsDetected ? 1 : 0;

    chakraLinkFade +=
        (chakraLinkTargetFade - chakraLinkFade) *
        Math.min(1, delta * 7);

    if (
        chakraLinkFade < 0.01 &&
        chakraLinkTargetFade === 0
    ) {

        chakraLinkGroup.visible = false;
        return;

    }

    if (!bothHandsDetected) {

        chakraLinkGroup.visible = true;

        applyEffectFade(chakraLinkGroup, chakraLinkFade);
        return;

    }

    const firstPalm = getPalmPosition(detectedHands[0]);
    const secondPalm = getPalmPosition(detectedHands[1]);

    if (!firstPalm || !secondPalm) return;

    const viewHeight =
        2 * threeCamera.position.z *
        Math.tan(
            THREE.MathUtils.degToRad(threeCamera.fov / 2)
        );

    const viewWidth = viewHeight * threeCamera.aspect;

    const firstPosition = new THREE.Vector3(
        firstPalm.x * viewWidth / 2,
        firstPalm.y * viewHeight / 2,
        -0.25
    );

    const secondPosition = new THREE.Vector3(
        secondPalm.x * viewWidth / 2,
        secondPalm.y * viewHeight / 2,
        -0.25
    );

    const direction = new THREE.Vector3()
        .subVectors(secondPosition, firstPosition);

    const distance = direction.length();

    if (distance < 0.05) return;

    const midpoint = new THREE.Vector3()
        .addVectors(firstPosition, secondPosition)
        .multiplyScalar(0.5);

    chakraLinkGroup.position.copy(midpoint);

    direction.normalize();

    chakraLinkGroup.quaternion.setFromUnitVectors(
        new THREE.Vector3(0, 1, 0),
        direction
    );

    const beamLength = THREE.MathUtils.clamp(
        distance, 0.15, 20
    );

    chakraLinkCore.scale.set(1, beamLength, 1);
    chakraLinkGlow.scale.set(1, beamLength, 1);

    const color = getChakraConnectionColor();

    chakraLinkCore.material.color.setHex(color);
    chakraLinkGlow.material.color.setHex(color);
    chakraLinkBranches.material.color.setHex(color);

    chakraLinkPulses.forEach(pulse => {
        pulse.material.color.setHex(color);
    });

    const ultimateBoost = ultimateActive ? 1.8 : 1;

    const energyPulse =
        1 + Math.sin(time * 12) * 0.12;

    chakraLinkCore.material.userData.effectOpacity =
        0.85 * energyPulse * ultimateBoost;

    chakraLinkGlow.material.userData.effectOpacity =
        0.25 * energyPulse * ultimateBoost;

    chakraLinkBranches.material.userData.effectOpacity =
        0.7 + Math.sin(time * 20) * 0.2;

    updateChakraBranches(time, beamLength);

    chakraLinkPulses.forEach((pulse, index) => {

        const phase =
            (
                time * pulse.userData.speed +
                pulse.userData.phase
            ) % 1;

        pulse.position.set(
            0,
            (phase - 0.5) * beamLength,
            0
        );

        const pulseSize =
            1 + Math.sin(time * 15 + index) * 0.2;

        pulse.scale.setScalar(
            pulseSize * (ultimateActive ? 1.35 : 1)
        );

        pulse.material.userData.effectOpacity =
            0.75 + Math.sin(time * 16 + index) * 0.2;

    });

    chakraLinkGroup.visible = true;

    applyEffectFade(chakraLinkGroup, chakraLinkFade);

}

// =========================================================
// ULTIMATE CHAKRA MODE
// =========================================================

function buildUltimateChakra() {

    ultimateGroup = new THREE.Group();
    ultimateGroup.visible = false;

    ultimateGroup.userData.lastPosition =
        new THREE.Vector3(0, 0, 0);

    ultimateGroup.userData.lastScale = 1;

    ultimateCore = addSphere(
        ultimateGroup,
        0.85,
        0x087dff,
        0.35,
        [1, 1, 0.85]
    );

    const innerCore = addSphere(
        ultimateGroup,
        0.48,
        0x8cecff,
        0.65
    );

    innerCore.userData.role = "ultimateCore";

    ultimateRings = [];

    for (let i = 0; i < 7; i++) {

        const ring = addTorus(
            ultimateGroup,
            0.95 + i * 0.09,
            0.018,
            i % 2 ? 0x8cecff : 0xffffff,
            0.8
        );

        ring.rotation.set(
            Math.random() * Math.PI,
            Math.random() * Math.PI,
            Math.random() * Math.PI
        );

        ring.userData.spin =
            i % 2 ? 2.2 : -2.2;

        ultimateRings.push(ring);

    }

    ultimateParticles = createParticleField(
        ultimateGroup, 450, 0x75dfff, 3.5, 0.045
    );

    scene.add(ultimateGroup);
    captureEffectMaterials(ultimateGroup);

}

// =========================================================
// ULTIMATE CHAKRA BLAST — ADVANCED BUILD
// =========================================================

function buildChakraBlast() {

    chakraBlastGroup = new THREE.Group();
    chakraBlastGroup.visible = false;

    // Main chakra core.

    chakraBlastCore = addSphere(
        chakraBlastGroup,
        0.8,
        0x42cfff,
        0.7
    );

    // Inner white energy core.

    const innerCore = addSphere(
        chakraBlastGroup,
        0.43,
        0xffffff,
        0.95
    );

    innerCore.userData.role = "blastInnerCore";

    // Outer blue glow.

    chakraBlastGlow = addSphere(
        chakraBlastGroup,
        1.12,
        0x168cff,
        0.2
    );

    // White release flash.

    chakraBlastFlash = addSphere(
        chakraBlastGroup,
        1.45,
        0xffffff,
        0,
        [1.25, 1.25, 1.25]
    );

    chakraBlastFlash.visible = false;
    chakraBlastFlash.userData.role = "blastFlash";

    // Nine rotating chakra rings.

    chakraBlastRings = [];

    for (let i = 0; i < 9; i++) {

        const ring = addTorus(
            chakraBlastGroup,
            0.95 + i * 0.12,
            0.025,
            i % 2 ? 0x70eaff : 0xffffff,
            0.85
        );

        ring.rotation.set(
            Math.random() * Math.PI,
            Math.random() * Math.PI,
            Math.random() * Math.PI
        );

        ring.userData.spin =
            i % 2 ? 2.2 : -2.2;

        chakraBlastRings.push(ring);

    }

    // Forward energy beam.

    const beamGeometry = new THREE.CylinderGeometry(
        0.12,
        0.65,
        1,
        32,
        1,
        true
    );

    chakraBlastBeam = new THREE.Mesh(
        beamGeometry,
        makeGlowMaterial(0x65dfff, 0.65)
    );

    chakraBlastBeam.rotation.x = Math.PI / 2;
    chakraBlastBeam.position.z = -1.8;
    chakraBlastBeam.scale.y = 3;

    chakraBlastGroup.add(chakraBlastBeam);

    // Five expanding shockwaves.

    chakraBlastShockwaves = [];

    for (let i = 0; i < 5; i++) {

        const shockwave = addTorus(
            chakraBlastGroup,
            0.8,
            0.035,
            0x9df5ff,
            0.9
        );

        shockwave.visible = false;

        shockwave.userData.expansion = 0;
        shockwave.userData.delay = i * 0.08;

        chakraBlastShockwaves.push(shockwave);

    }

    // 520 chakra particles.

    chakraBlastParticles = createParticleField(
        chakraBlastGroup,
        520,
        0x75eaff,
        3.5,
        0.045
    );

    scene.add(chakraBlastGroup);

    captureEffectMaterials(chakraBlastGroup);

}

// =========================================================
// CHAKRA BLAST — PARTICLE EXPLOSION
// =========================================================

function resetChakraBlastParticles() {

    if (!chakraBlastParticles) return;

    const positions =
        chakraBlastParticles.geometry.attributes.position.array;

    const velocities =
        chakraBlastParticles.userData.velocities;

    for (let i = 0; i < velocities.length; i++) {

        const p = i * 3;

        // Start every particle at the centre.

        positions[p] = 0;
        positions[p + 1] = 0;
        positions[p + 2] = 0;

        // Random outward direction.

        const direction = new THREE.Vector3(
            Math.random() * 2 - 1,
            Math.random() * 2 - 1,
            Math.random() * 2 - 1
        ).normalize();

        const speed =
            0.035 + Math.random() * 0.045;

        velocities[i] = {
            x: direction.x * speed,
            y: direction.y * speed,
            z: direction.z * speed
        };

    }

    chakraBlastParticles.geometry.attributes.position.needsUpdate = true;

    chakraBlastBurstStarted = true;

}

// =========================================================
// CHAKRA BLAST — OUTWARD PARTICLE MOVEMENT
// =========================================================

function updateChakraBlastParticles(delta, progress) {

    if (!chakraBlastParticles) return;

    const positions =
        chakraBlastParticles.geometry.attributes.position.array;

    const velocities =
        chakraBlastParticles.userData.velocities;

    for (let i = 0; i < velocities.length; i++) {

        const p = i * 3;
        const v = velocities[i];

        positions[p] += v.x * delta * 60;
        positions[p + 1] += v.y * delta * 60;
        positions[p + 2] += v.z * delta * 60;

    }

    chakraBlastParticles.geometry.attributes.position.needsUpdate = true;

    chakraBlastParticles.material.userData.effectOpacity =
        Math.max(0, 0.9 * (1 - progress));

}

// =========================================================
// CHAKRA BLAST — ADVANCED RELEASE
// =========================================================

function releaseChakraBlast() {

    if (!chakraBlastGroup) return;
    if (chakraBlastCharge < 0.15) return;

    chakraBlastPhase = "blasting";
    chakraBlastActive = true;
    chakraBlastTimer = 0;

    chakraBlastGroup.visible = true;

    // Reset all shockwaves.

    chakraBlastShockwaves.forEach(ring => {

        ring.visible = true;
        ring.userData.expansion = 0;

        ring.scale.setScalar(1);

        ring.material.userData.effectOpacity = 0.9;

    });

    // Reset the particle explosion.

    resetChakraBlastParticles();

    // Reset the white flash.

    chakraBlastFlash.visible = true;

    chakraBlastFlash.material.userData.effectOpacity = 0;

    chakraBlastFlash.scale.setScalar(1);

    // Position the blast between both palms.

    const firstPalm = getPalmPosition(detectedHands[0]);
    const secondPalm = getPalmPosition(detectedHands[1]);

    if (firstPalm && secondPalm) {

        const viewHeight =
            2 * threeCamera.position.z *
            Math.tan(
                THREE.MathUtils.degToRad(threeCamera.fov / 2)
            );

        const viewWidth = viewHeight * threeCamera.aspect;

        chakraBlastGroup.position.set(

            ((firstPalm.x + secondPalm.x) / 2) *
                viewWidth / 2,

            ((firstPalm.y + secondPalm.y) / 2) *
                viewHeight / 2,

            0

        );

        const distance = Math.hypot(
            firstPalm.x - secondPalm.x,
            firstPalm.y - secondPalm.y
        );

        chakraBlastGroup.userData.releaseScale =
            THREE.MathUtils.clamp(
                distance * 1.4,
                0.8,
                CHAKRA_BLAST_CONFIG.maxScale
            );

    }

    chakraBlastGroup.scale.setScalar(
        chakraBlastGroup.userData.releaseScale || 1
    );

    // Initial energy intensity.

    chakraBlastCore.material.userData.effectOpacity = 0.9;

    chakraBlastGlow.material.userData.effectOpacity = 0.85;

    chakraBlastBeam.material.userData.effectOpacity = 0.95;

    chakraBlastRings.forEach(ring => {

        ring.material.userData.effectOpacity = 0.95;

    });

}

// =========================================================
// CHAKRA BLAST — GESTURE CONTROL
// =========================================================

function updateChakraBlastGesture(delta) {

    // Cooldown continues even when hands are not detected.

    if (chakraBlastCooldown > 0) {

        chakraBlastCooldown = Math.max(
            0,
            chakraBlastCooldown - delta
        );

    }

    if (detectedHands.length !== 2) {

        if (chakraBlastPhase === "charging") {
            chakraBlastPhase = "idle";
        }

        previousBlastGesture = false;

        return;

    }

    const firstHand = detectedHands[0];
    const secondHand = detectedHands[1];

    const firstOpen =
        getFingerStates(firstHand).every(Boolean);

    const secondOpen =
        getFingerStates(secondHand).every(Boolean);

    const firstFist = isFist(firstHand);
    const secondFist = isFist(secondHand);

    const bothOpen = firstOpen && secondOpen;
    const bothFists = firstFist && secondFist;

    if (
        bothOpen &&
        chakraBlastPhase !== "blasting" &&
        chakraBlastCooldown <= 0
    ) {

        chakraBlastPhase = "charging";

        chakraBlastCharge +=
            delta / CHAKRA_BLAST_CONFIG.chargeTime;

        chakraBlastCharge = THREE.MathUtils.clamp(
            chakraBlastCharge,
            0,
            1
        );

    }

    if (
        bothFists &&
        !previousBlastGesture &&
        chakraBlastCharge >= 0.15 &&
        chakraBlastCooldown <= 0 &&
        chakraBlastPhase !== "blasting"
    ) {

        releaseChakraBlast();

    }

    previousBlastGesture = bothFists;

}

// =========================================================
// CHAKRA BLAST — ADVANCED ANIMATION
// =========================================================

function animateChakraBlast(delta, time) {

    if (!chakraBlastGroup) return;

    // Hide completely when idle and uncharged.

    if (
        chakraBlastPhase === "idle" &&
        chakraBlastCharge <= 0
    ) {

        chakraBlastGroup.visible = false;
        chakraBlastFlash.visible = false;

        return;

    }

    chakraBlastGroup.visible = true;

    // =====================================================
    // CHARGING ANIMATION
    // =====================================================

    if (chakraBlastPhase === "charging") {

        const chargePulse =
            1 + Math.sin(time * 10) * 0.08;

        const chargeScale =
            0.65 + chakraBlastCharge * 0.85;

        chakraBlastGroup.scale.setScalar(
            chargeScale * chargePulse
        );

        // Rotate all nine rings.

        chakraBlastRings.forEach((ring, index) => {

            ring.rotation.x +=
                delta * (2 + index * 0.2);

            ring.rotation.y -=
                delta * (1.5 + index * 0.2);

            ring.rotation.z += delta * 0.8;

        });

        // Glow increases with charge.

        chakraBlastGlow.material.userData.effectOpacity =
            0.2 + chakraBlastCharge * 0.65;

        chakraBlastCore.material.userData.effectOpacity =
            0.5 + chakraBlastCharge * 0.4;

        chakraBlastBeam.material.userData.effectOpacity =
            chakraBlastCharge * 0.35;

        chakraBlastParticles.material.userData.effectOpacity = 0.9;

        chakraBlastShockwaves.forEach(ring => {
            ring.visible = false;
        });

        chakraBlastFlash.visible = false;

        updateParticles(
            chakraBlastParticles,
            delta,
            time
        );

    }

    // =====================================================
    // ULTIMATE BLAST RELEASE
    // =====================================================

    if (chakraBlastPhase === "blasting") {

        chakraBlastTimer += delta;

        const progress = THREE.MathUtils.clamp(
            chakraBlastTimer /
                CHAKRA_BLAST_CONFIG.blastDuration,
            0,
            1
        );

        // Massive expanding energy sphere.

        const releaseScale =
            chakraBlastGroup.userData.releaseScale || 1;

        const blastScale =
            releaseScale *
            (1 + progress * CHAKRA_BLAST_CONFIG.expansionSpeed);

        chakraBlastGroup.scale.setScalar(blastScale);

        // -------------------------------------------------
        // ROTATING CHAKRA RINGS
        // -------------------------------------------------

        chakraBlastRings.forEach((ring, index) => {

            ring.rotation.x += delta * (9 + index * 0.3);
            ring.rotation.y += delta * (7 + index * 0.25);
            ring.rotation.z += delta * (5 + index * 0.2);

            ring.material.userData.effectOpacity =
                Math.max(0, 0.95 * (1 - progress));

        });

        // -------------------------------------------------
        // ENERGY BEAM
        // -------------------------------------------------

        chakraBlastBeam.material.userData.effectOpacity =
            Math.max(0, 0.95 * (1 - progress));

        chakraBlastGlow.material.userData.effectOpacity =
            Math.max(0, 0.85 * (1 - progress));

        chakraBlastCore.material.userData.effectOpacity =
            Math.max(0, 0.9 * (1 - progress));

        // -------------------------------------------------
        // WHITE ENERGY FLASH
        // -------------------------------------------------

        if (progress < 0.22) {

            chakraBlastFlash.visible = true;

            const flashProgress = progress / 0.22;

            chakraBlastFlash.scale.setScalar(
                1 + flashProgress * 2.5
            );

            chakraBlastFlash.material.userData.effectOpacity =
                Math.max(0, 1 - flashProgress);

        } else {

            chakraBlastFlash.visible = false;

            chakraBlastFlash.material.userData.effectOpacity = 0;

        }

        // -------------------------------------------------
        // FIVE EXPANDING SHOCKWAVES
        // -------------------------------------------------

        chakraBlastShockwaves.forEach((ring, index) => {

            const localProgress = THREE.MathUtils.clamp(
                progress - ring.userData.delay,
                0,
                1
            );

            ring.userData.expansion = localProgress;

            ring.scale.setScalar(
                1 + localProgress * 9
            );

            ring.material.userData.effectOpacity =
                Math.max(
                    0,
                    0.9 * (1 - localProgress)
                );

            ring.rotation.x += delta * (2 + index * 0.2);
            ring.rotation.y += delta * (1.5 + index * 0.15);

        });

        // -------------------------------------------------
        // OUTWARD PARTICLE EXPLOSION
        // -------------------------------------------------

        if (chakraBlastBurstStarted) {

            updateChakraBlastParticles(
                delta,
                progress
            );

        }

        // -------------------------------------------------
        // BLAST COMPLETION
        // -------------------------------------------------

        if (progress >= 1) {

            chakraBlastPhase = "idle";
            chakraBlastActive = false;

            chakraBlastCharge = 0;

            chakraBlastCooldown =
                CHAKRA_BLAST_CONFIG.cooldownTime;

            chakraBlastFlash.visible = false;

            chakraBlastShockwaves.forEach(ring => {
                ring.visible = false;
            });

            chakraBlastBurstStarted = false;
            chakraBlastGroup.scale.setScalar(1);
            chakraBlastShockwaves.forEach(ring => ring.scale.setScalar(1));

        }

    }

    // =====================================================
    // IDLE / ENERGY DRAIN
    // =====================================================

    if (chakraBlastPhase === "idle") {

        chakraBlastCharge = Math.max(
            0,
            chakraBlastCharge - delta * 0.8
        );

        chakraBlastGlow.material.userData.effectOpacity = 0.2;

        chakraBlastCore.material.userData.effectOpacity = 0.5;

        chakraBlastBeam.material.userData.effectOpacity = 0;

        chakraBlastFlash.visible = false;

        chakraBlastGroup.scale.lerp(
            new THREE.Vector3(0.001, 0.001, 0.001),
            Math.min(1, delta * 5)
        );

        if (chakraBlastCharge <= 0.001) {
            chakraBlastGroup.visible = false;
        }

    }

    // Apply overall effect opacity.

    applyEffectFade(
        chakraBlastGroup,
        chakraBlastPhase === "blasting"
            ? Math.max(
                0,
                1 - chakraBlastTimer /
                    CHAKRA_BLAST_CONFIG.blastDuration
            )
            : 1
    );

}

// =========================================================
// MEDIAPIPE HAND TRACKING + GESTURE PROCESSING

function smoothLandmarks(label, landmarks) {
    const previous = handSmoothing.get(label);
    const alpha = 0.62;

    const result = landmarks.map((point, index) => {
        if (!previous || !previous[index]) return { ...point };
        return {
            x: previous[index].x + (point.x - previous[index].x) * alpha,
            y: previous[index].y + (point.y - previous[index].y) * alpha,
            z: (previous[index].z || 0) + ((point.z || 0) - (previous[index].z || 0)) * alpha
        };
    });

    handSmoothing.set(label, result);
    return result;
}

function processHandResults(results) {
    if (!handCtx || !handCanvas) return;

    const width = video.videoWidth || 640;
    const height = video.videoHeight || 480;
    if (handCanvas.width !== width) handCanvas.width = width;
    if (handCanvas.height !== height) handCanvas.height = height;

    handCtx.clearRect(0, 0, width, height);

    const rawHands = results.multiHandLandmarks || [];
    const handedness = results.multiHandedness || [];
    const entries = rawHands.map((landmarks, index) => ({
        label: handedness[index]?.label || `Hand${index}`,
        landmarks: smoothLandmarks(handedness[index]?.label || `Hand${index}`, landmarks)
    })).sort((a, b) => a.label.localeCompare(b.label));

    if (typeof drawConnectors === "function" && typeof HAND_CONNECTIONS !== "undefined") {
        entries.forEach(entry => {
            drawConnectors(handCtx, entry.landmarks, HAND_CONNECTIONS, {
                color: "#55dfff", lineWidth: 3
            });
            if (typeof drawLandmarks === "function") {
                drawLandmarks(handCtx, entry.landmarks, {
                    color: "#ffffff", lineWidth: 1, radius: 2
                });
            }
        });
    }

    detectedHands = entries.slice(0, 2).map(entry => entry.landmarks);
    activeHands = detectedHands.slice();
    fingerStatesByHand = [];

    const newlyActivated = [];

    for (let i = 0; i < 2; i++) {
        const landmarks = detectedHands[i];
        if (!landmarks) {
            fistHistory[i] = [];
            handJutsu[i] = null;
            previousHandPower[i] = null;
            if (effectGroups[i]) {
                effectGroups[i].userData.targetFade = 0;
                effectGroups[i].userData.lastLandmarks = null;
            }
            continue;
        }

        const states = getFingerStates(landmarks);
        fingerStatesByHand[i] = states;

        // Palm/fist control only: no Naruto hand-seal recognition.
        const fistNow = isFist(landmarks);
        fistHistory[i].push(fistNow);
        if (fistHistory[i].length > 5) fistHistory[i].shift();
        const stableFist = fistHistory[i].length >= 4 &&
            fistHistory[i].slice(-4).every(Boolean);
        const activePower = stableFist ? selectedPower : null;

        if (activePower && previousHandPower[i] !== activePower) {
            newlyActivated.push({ index: i, power: activePower });
        }
        previousHandPower[i] = activePower;
        handJutsu[i] = activePower;

        if (effectGroups[i]) {
            effectGroups[i].userData.lastLandmarks = landmarks;
            effectGroups[i].userData.targetFade = activePower ? 1 : 0;
        }
        updateHandJutsu(i, activePower || selectedPower);
    }

    // Both hands activating the same selected technique together earns a Dual Sync.
    const simultaneousPair = newlyActivated.length === 2 &&
        newlyActivated[0].power === newlyActivated[1].power;
    if (simultaneousPair && comboDualSyncCooldown <= 0) {
        registerComboActivation(newlyActivated[0].power, true);
        comboDualSyncCooldown = 1.4;
    } else {
        newlyActivated.forEach(item => registerComboActivation(item.power, false));
    }
    if (typeof v37Notify === "function") {
        newlyActivated.forEach(item => v37Notify(`${JUTSU_NAMES[item.power]} ACTIVATED`, item.power));
        if (simultaneousPair && comboDualSyncCooldown > 0) {
            v37Notify("CHAKRA SYNCHRONIZED", "sync");
        }
    }

    if (!detectedHands.length) {
        handJutsu = [null, null];
        fistHistory = [[], []];
        previousHandPower = [null, null];
        effectGroups.forEach(group => {
            group.userData.targetFade = 0;
            group.userData.lastLandmarks = null;
        });
    }

    trackingReady = true;
    if (handStatus) {
        handStatus.textContent = detectedHands.length
            ? `${detectedHands.length} HAND${detectedHands.length > 1 ? "S" : ""} DETECTED`
            : "NO HANDS DETECTED";
    }
    if (detection) detection.textContent = detectedHands.length ? "TRACKING" : "SEARCHING";
    if (typeof v37UpdateHandLocks === "function") v37UpdateHandLocks();
    updateSystemStatus();
}

async function initializeMediaPipe() {
    if (hands) return;

    if (typeof Hands === "undefined") {
        throw new Error("MediaPipe Hands library is missing. Check the MediaPipe script tags in index.html.");
    }
    if (typeof Camera === "undefined") {
        throw new Error("MediaPipe Camera utility is missing. Check the camera_utils script tag in index.html.");
    }

    hands = new Hands({
        locateFile: file => `https://cdn.jsdelivr.net/npm/@mediapipe/hands/${file}`
    });

    hands.setOptions({
        maxNumHands: 2,
        modelComplexity: 1,
        minDetectionConfidence: 0.68,
        minTrackingConfidence: 0.62
    });

    hands.onResults(processHandResults);
    await hands.initialize?.();
    trackingReady = true;
}

function updateUltimateModeGesture(delta) {
    if (ultimateGestureCooldown > 0) {
        ultimateGestureCooldown = Math.max(0, ultimateGestureCooldown - delta);
    }

    if (detectedHands.length !== 2) {
        ultimateGestureHold = 0;
        previousUltimateGesture = false;
        return;
    }

    // Hold a thumbs-up with both hands for about 1.35 seconds to toggle Ultimate Mode.
    const bothThumbsUp = detectedHands.every(hand => {
        const f = getFingerStates(hand);
        return f[0] && !f[1] && !f[2] && !f[3] && !f[4];
    });

    if (bothThumbsUp && ultimateGestureCooldown <= 0) {
        ultimateGestureHold += delta;
        if (ultimateGestureHold >= 1.35 && !previousUltimateGesture) {
            ultimateActive = !ultimateActive;
            ultimateTargetFade = ultimateActive ? 1 : 0;
            ultimateGestureCooldown = 1.6;
            previousUltimateGesture = true;
            if (!ultimateActive) {
                ultimateCharge = 0;
                ultimateMaxCharge = false;
            }
        }
    } else {
        ultimateGestureHold = 0;
        previousUltimateGesture = false;
    }
}

// FINGER DETECTION
// =========================================================

function getFingerStates(landmarks) {

    const wrist = landmarks[0];

    function distance(a, b) {

        return Math.hypot(
            a.x - b.x,
            a.y - b.y
        );

    }

    const fingers = [
        { tip: 4, joint: 3 },
        { tip: 8, joint: 6 },
        { tip: 12, joint: 10 },
        { tip: 16, joint: 14 },
        { tip: 20, joint: 18 }
    ];

    return fingers.map(finger => {

        return distance(
            wrist,
            landmarks[finger.tip]
        ) >
        distance(
            wrist,
            landmarks[finger.joint]
        ) * 1.08;

    });

}

function formatFingerStates(states) {

    const names = ["T", "I", "M", "R", "L"];

    return names.map((name, index) =>
        `${name}:${states[index] ? "O" : "C"}`
    ).join(" ");

}

// =========================================================
// FIST RECOGNITION
// =========================================================

function isFist(landmarks) {

    const wrist = landmarks[0];

    const tips = [8, 12, 16, 20];
    const pips = [6, 10, 14, 18];

    let curled = 0;

    tips.forEach((tip, index) => {

        const tipDistance = Math.hypot(
            landmarks[tip].x - wrist.x,
            landmarks[tip].y - wrist.y
        );

        const pipDistance = Math.hypot(
            landmarks[pips[index]].x - wrist.x,
            landmarks[pips[index]].y - wrist.y
        );

        if (tipDistance < pipDistance * 1.15) {
            curled++;
        }

    });

    return curled >= 3;

}

// =========================================================
// PALM POSITION
// =========================================================

function getPalmPosition(landmarks) {

    if (
        !landmarks ||
        !video.videoWidth ||
        !video.videoHeight
    ) {
        return null;
    }

    const points = [5, 9, 13, 17];

    let nx = 0;
    let ny = 0;

    points.forEach(index => {
        nx += landmarks[index].x;
        ny += landmarks[index].y;
    });

    nx /= points.length;
    ny /= points.length;

    const dx =
        (landmarks[5].x - landmarks[17].x) *
        video.videoWidth;

    const dy =
        (landmarks[5].y - landmarks[17].y) *
        video.videoHeight;

    const palmWidth = Math.hypot(dx, dy);

    const panel =
        fxCanvas.parentElement.getBoundingClientRect();

    const sourceAspect =
        video.videoWidth / video.videoHeight;

    const panelAspect =
        panel.width / panel.height;

    let viewX = nx;
    let viewY = ny;

    if (sourceAspect > panelAspect) {

        const visibleWidth =
            panelAspect / sourceAspect;

        viewX =
            (nx - (1 - visibleWidth) / 2) /
            visibleWidth;

    } else {

        const visibleHeight =
            sourceAspect / panelAspect;

        viewY =
            (ny - (1 - visibleHeight) / 2) /
            visibleHeight;

    }

    const x = (viewX - 0.5) * 2;
    const y = (0.5 - viewY) * 2;

    const normalizedPalm =
        palmWidth / video.videoWidth;

    const worldRadius = THREE.MathUtils.clamp(
        normalizedPalm * 9.2,
        0.85,
        2.1
    );

    return {
        x,
        y,
        radius: worldRadius
    };

}

// =========================================================
// PARTICLE ANIMATION
// =========================================================

function updateParticles(points, delta, time) {

    if (!points) return;

    const positions =
        points.geometry.attributes.position.array;

    const velocities =
        points.userData.velocities;

    const spread =
        points.userData.spread;

    for (let i = 0; i < velocities.length; i++) {

        const p = i * 3;
        const v = velocities[i];

        positions[p] += v.x * (delta * 60);
        positions[p + 1] += v.y * (delta * 60);
        positions[p + 2] += v.z * (delta * 60);

        if (positions[p + 1] > spread * 0.55) {

            positions[p] =
                (Math.random() - 0.5) * spread;

            positions[p + 1] =
                -spread * 0.45;

            positions[p + 2] =
                (Math.random() - 0.5) * spread;

        }

    }

    points.geometry.attributes.position.needsUpdate = true;

    points.rotation.y = Math.sin(time * 0.35) * 0.12;

}

// =========================================================
// ADVANCED JUTSU ANIMATION
// =========================================================

function animateEffectGroup(
    group,
    particles,
    delta,
    time
) {

    if (!group) return;

    const targetFade = group.userData.targetFade || 0;

    group.userData.fade +=
        (targetFade - group.userData.fade) *
        Math.min(1, delta * 8);

    const fade = group.userData.fade;

    if (fade < 0.01 && targetFade === 0) {
        group.visible = false;
        return;
    }

    const landmarks = group.userData.lastLandmarks;

    if (!landmarks) {
        group.visible = false;
        return;
    }

    const palm = getPalmPosition(landmarks);

    if (!palm) {
        group.visible = false;
        return;
    }

    group.visible = true;

    const power = group.userData.power;

    let energyPulse = 1;

    if (power === "fire") {
        energyPulse = 1 + Math.sin(time * 8) * 0.055;
    }

    if (power === "rasengan") {
        energyPulse = 1 + Math.sin(time * 13) * 0.035;
    }

    if (power === "lightning") {

        energyPulse =
            1 + Math.sin(time * 22) * 0.025 +
            (Math.random() < 0.09 ? 0.12 : 0);

    }

    if (power === "rasenshuriken") {
        energyPulse = 1 + Math.sin(time * 11) * 0.045;
    }

    const viewHeight =
        2 * threeCamera.position.z *
        Math.tan(
            THREE.MathUtils.degToRad(threeCamera.fov / 2)
        );

    const viewWidth = viewHeight * threeCamera.aspect;

    group.position.set(
        palm.x * viewWidth / 2,
        palm.y * viewHeight / 2,
        0
    );

    const handIndex = effectGroups.indexOf(group);
    const evolution = handIndex >= 0 ? (jutsuEvolutionStage[handIndex] || 0) : 0;
    const evolutionScale = evolution === 2 ? 1.22 : evolution === 1 ? 1.10 : 1;
    group.scale.setScalar(palm.radius * energyPulse * evolutionScale);

    group.children.forEach(child => {

        const role = child.userData.role;

        if (role === "flame") {

            child.rotation.z =
                time * 2.4 + child.userData.phase;

            child.scale.y =
                1.9 +
                Math.sin(
                    time * 12 + child.userData.phase
                ) * 0.75;

            child.scale.x =
                0.7 +
                Math.sin(
                    time * 9 + child.userData.phase
                ) * 0.15;

            child.position.x =
                Math.cos(
                    child.userData.phase + time * 1.1
                ) * 0.68;

            child.position.y =
                Math.sin(
                    child.userData.phase + time * 1.1
                ) * 0.68;

        }

        if (role === "smoke") {

            child.position.y += delta * 0.28;

            child.material.userData.effectOpacity =
                0.07 +
                (
                    Math.sin(
                        time * 2.5 + child.userData.phase
                    ) + 1
                ) * 0.035;

            if (child.position.y > 1.65) {
                child.position.y = 0.55;
            }

        }

        if (role === "shell") {

            const pulse =
                1 +
                Math.sin(
                    time * 6 + child.userData.phase
                ) * 0.13;

            child.scale.set(
                pulse,
                pulse,
                pulse * 0.8
            );

            child.rotation.y += delta * 1.1;
            child.rotation.x += delta * 0.6;

        }

        if (
            role === "ring" ||
            role === "chakraRing" ||
            role === "stream" ||
            role === "electricRing"
        ) {

            let speed = 1;

            if (power === "fire") speed = 1.8;
            if (power === "rasengan") speed = 2.8;
            if (power === "lightning") speed = 2.5;

            child.rotation.x +=
                delta *
                (child.userData.spin || 0.7) *
                speed;

            child.rotation.y +=
                delta *
                (child.userData.spin || 0.7) *
                0.7 *
                speed;

            child.rotation.z += delta * 0.35 * speed;

        }

        if (
            role === "core" ||
            role === "hotCore" ||
            role === "whiteCore"
        ) {

            const pulse =
                1 + Math.sin(time * 9) * 0.065;

            child.scale.set(pulse, pulse, pulse);

        }

        if (role === "arc") {

            child.rotation.z =
                time * (child.userData.speed || 4.5) +
                child.userData.phase;

            const flicker =
                0.35 + Math.random() * 0.65;

            child.material.userData.effectOpacity =
                (child.userData.baseOpacity || 0.7) * flicker;

        }

        if (role === "electricCore") {

            const pulse =
                0.88 + Math.sin(time * 24) * 0.12;

            child.scale.setScalar(pulse);
            child.material.userData.effectOpacity =
                0.68 + Math.random() * 0.3;

        }

        if (role === "chidoriGlow") {

            const pulse =
                1 + Math.sin(time * 15 + child.id) * 0.09;

            child.scale.set(
                pulse,
                pulse,
                pulse * 0.9
            );

            child.material.userData.effectOpacity =
                0.18 + (Math.sin(time * 18 + child.id) + 1) * 0.07;

        }

        if (
            role === "chidoriGlowBolt" ||
            role === "chidoriBlueBolt" ||
            role === "chidoriWhiteBolt"
        ) {

            const flicker = 0.58 + Math.random() * 0.42;
            const pulse = 0.82 + (Math.sin(time * 19 + child.userData.phase) + 1) * 0.12;
            child.material.userData.effectOpacity =
                child.userData.baseOpacity * flicker * pulse;
            // The lightning surges outward from the palm in a flowing stream.
            child.scale.x = 0.96 + (Math.sin(time * 13 + child.userData.phase) + 1) * 0.055;
            child.rotation.z = Math.sin(time * 5.5 + child.userData.phase) * 0.012;

        }

        if (role === "chidoriPalmFlash") {
            const pulse = 0.88 + Math.sin(time * 26 + child.id) * 0.12;
            child.scale.set(0.95 * pulse, 0.48 * pulse, 0.62 * pulse);
            child.material.userData.effectOpacity =
                0.48 + Math.random() * 0.32;
        }

        if (role === "rasenshurikenRotor") {
            child.rotation.z += delta * (child.userData.spin || 2.7);
        }

        if (role === "rasenshurikenOrb") {
            const pulse = 0.97 + Math.sin(time * 7 + child.id) * 0.025;
            child.scale.set(pulse, pulse, pulse * 0.92);
            child.material.userData.effectOpacity = child.material.userData.baseOpacity *
                (0.92 + Math.sin(time * 8 + child.id) * 0.08);
        }

        if (role === "rasenshurikenOrbStream") {
            child.rotation.x += delta * child.userData.spin;
            child.rotation.y += delta * child.userData.spin * 0.7;
            child.material.userData.effectOpacity = 0.28 + (Math.sin(time * 8 + child.id) + 1) * 0.08;
        }

        if (role === "rasenshurikenWindWisp") {
            child.material.userData.effectOpacity = 0.16 + (Math.sin(time * 10 + child.userData.phase) + 1) * 0.10;
        }

        if (role === "rasenshurikenBlade") {
            child.rotation.z += delta * (child.userData.spin || 2.8);
            const pulse = 0.94 + Math.sin(time * 12 + child.userData.phase) * 0.06;
            child.scale.setScalar(pulse);
            child.material.userData.effectOpacity = 0.42 + (Math.sin(time * 16 + child.userData.phase) + 1) * 0.13;
        }

        if (role === "rasenshurikenBlade") {
            const pulse = 0.96 + Math.sin(time * 13 + child.userData.phase) * 0.04;
            child.scale.setScalar(pulse);
            child.material.userData.effectOpacity = 0.78 + (Math.sin(time * 15 + child.userData.phase) + 1) * 0.08;
        }

        if (role === "rasenshurikenRing") {
            child.rotation.z += delta * (child.userData.spin || -2.2);
            child.material.userData.effectOpacity = 0.42 + (Math.sin(time * 9 + child.userData.phase) + 1) * 0.12;
        }

        if (role === "rasenshurikenCore") {
            const pulse = 0.9 + Math.sin(time * 18) * 0.1;
            child.scale.setScalar(pulse);
            child.material.userData.effectOpacity = 0.62 + Math.random() * 0.25;
        }

        if (role === "windStreak") {
            child.rotation.z = Math.sin(time * 5 + child.userData.phase) * 0.18;
            child.material.userData.effectOpacity = 0.22 + (Math.sin(time * 13 + child.userData.phase) + 1) * 0.16;
        }

    });

    applyEffectFade(group, fade);

    updateParticles(particles, delta, time);

}

// =========================================================
// ULTIMATE CHAKRA ANIMATION + CHARGING
// =========================================================

function animateUltimateChakra(delta, time) {

    if (!ultimateGroup) return;

    ultimateTargetFade = ultimateActive ? 1 : 0;

    if (ultimateActive) {
        ultimateCharge += delta / ULTIMATE_CHARGE_TIME;
    } else {
        ultimateCharge -= delta * 0.65;
    }

    ultimateCharge = THREE.MathUtils.clamp(
        ultimateCharge, 0, 1
    );

    ultimateMaxCharge = ultimateCharge >= 1;

    ultimateFade +=
        (ultimateTargetFade - ultimateFade) *
        Math.min(1, delta * 5);

    if (
        ultimateFade < 0.01 &&
        ultimateTargetFade === 0
    ) {

        ultimateGroup.visible = false;
        return;

    }

    if (detectedHands.length === 2) {

        const firstPalm =
            getPalmPosition(detectedHands[0]);

        const secondPalm =
            getPalmPosition(detectedHands[1]);

        if (firstPalm && secondPalm) {

            const middleX =
                (firstPalm.x + secondPalm.x) / 2;

            const middleY =
                (firstPalm.y + secondPalm.y) / 2;

            const distance = Math.hypot(
                firstPalm.x - secondPalm.x,
                firstPalm.y - secondPalm.y
            );

            const sphereSize = THREE.MathUtils.clamp(
                distance * 1.15, 0.7, 2.0
            );

            const viewHeight =
                2 * threeCamera.position.z *
                Math.tan(
                    THREE.MathUtils.degToRad(threeCamera.fov / 2)
                );

            const viewWidth =
                viewHeight * threeCamera.aspect;

            ultimateGroup.userData.lastPosition.set(
                middleX * viewWidth / 2,
                middleY * viewHeight / 2,
                0
            );

            ultimateGroup.userData.lastScale = sphereSize;

        }

    } else {

        ultimateTargetFade = 0;

    }

    ultimateGroup.position.copy(
        ultimateGroup.userData.lastPosition
    );

    const pulse = 1 + Math.sin(time * 8) * 0.04;
    const chargeScale = 1 + ultimateCharge * 0.45;

    ultimateGroup.scale.setScalar(
        ultimateGroup.userData.lastScale *
        pulse *
        chargeScale
    );

    ultimateGroup.visible = true;

    const chargeSpeed = 1 + ultimateCharge * 3;

    ultimateRings.forEach((ring, index) => {

        ring.rotation.x +=
            delta * ring.userData.spin * chargeSpeed;

        ring.rotation.y +=
            delta * ring.userData.spin * 0.8 * chargeSpeed;

        ring.rotation.z += delta * 1.1 * chargeSpeed;

        ring.material.userData.effectOpacity =
            0.45 +
            Math.sin(
                time * (5 + ultimateCharge * 10) + index
            ) * 0.25;

    });

    ultimateGroup.children.forEach(child => {

        if (child.userData.role === "ultimateCore") {

            const corePulse =
                1 +
                Math.sin(
                    time * (12 + ultimateCharge * 12)
                ) * 0.12;

            child.scale.setScalar(corePulse);

            child.material.userData.effectOpacity =
                0.65 + ultimateCharge * 0.3;

        }

    });

    applyEffectFade(ultimateGroup, ultimateFade);

    updateParticles(ultimateParticles, delta, time);

}

// =========================================================
// MAIN ANIMATION LOOP
// =========================================================

function animateThree() {

    requestAnimationFrame(animateThree);

    if (!renderer || !scene || !threeCamera) return;

    const delta = Math.min(
        clock.getDelta(),
        0.04
    );

    const time = clock.elapsedTime;

    // Gesture controls use the most recent MediaPipe results.
    updateComboSystem(delta);
    updateJutsuEvolutionSystem(delta);
    updateChakraBlastGesture(delta);
    updateUltimateModeGesture(delta);

    for (let i = 0; i < effectGroups.length; i++) {

        animateEffectGroup(
            effectGroups[i],
            particleSystems[i],
            delta,
            time
        );

    }

    animateUltimateChakra(delta, time);

    animateChakraBlast(delta, time);

    animateChakraShields(delta, time);

    animateChakraConnection(delta, time);
    animateAdvancedChakraAuras(delta, time);
    animateChakraCloaks(delta, time);
    animateDualHandFusion(delta, time);
    animateComboFinisher(delta, time);

    statusUpdateClock += delta;
    if (statusUpdateClock >= 0.15) {
        statusUpdateClock = 0;
        updateSystemStatus();
        updateChakraEvolutionHUD();
    }

    renderer.render(scene, threeCamera);

}

// =========================================================
// START CAMERA + MEDIAPIPE

startBtn.addEventListener("click", async () => {
    if (camera) return;

    try {
        startBtn.disabled = true;
        startBtn.textContent = "INITIALIZING...";
        if (cameraStatus) cameraStatus.textContent = "CONNECTING";

        if (!threeReady) initThree();
        await initializeMediaPipe();

        camera = new Camera(video, {
            onFrame: async () => {
                if (hands && video.readyState >= 2) {
                    await hands.send({ image: video });
                }
            },
            width: 640,
            height: 480
        });

        await camera.start();

        if (placeholder) placeholder.style.display = "none";
        if (cameraStatus) cameraStatus.textContent = "CONNECTED";
        startBtn.textContent = "SYSTEM ACTIVE";
        if (detection) detection.textContent = "SEARCHING";
        updateSystemStatus();

    } catch (error) {
        console.error("NINJA SYSTEM ERROR:", error);
        if (cameraStatus) cameraStatus.textContent = "ERROR";
        startBtn.disabled = false;
        startBtn.textContent = "RETRY SYSTEM";

        try {
            if (camera?.stop) await camera.stop();
        } catch (_) {}

        camera = null;
        trackingReady = false;

        alert(`${error.message || "The system could not start."}\n\nCheck camera permissions, internet connection, and the MediaPipe/Three.js script tags in index.html.`);
    }
});

// INITIALIZE THREE.JS
// =========================================================

try {

    initThree();

} catch (error) {

    console.error(error);

    cameraStatus.textContent = "3D ENGINE ERROR";

    startBtn.title =
        "Three.js could not initialize. Check WebGL and internet access.";

}
